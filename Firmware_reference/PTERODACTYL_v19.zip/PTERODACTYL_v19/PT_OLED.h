/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: Class to control an OLED display

#ifndef OLED_H
#define OLED_H
#include <Arduino.h>

/***********************************************************************************************************************************************
LED Class Definition
************************************************************************************************************************************************/
class OLED{
  public:
    void begin();
    void update(String disp);
  
  private:
    int _pin1;
    int _pin2;
};

#endif
/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This sketch is a Library that will help teach about the
//         creation of libraries

#include "my_library.h"

int addTwoInts(int a, int b)
{
  return a + b;
}
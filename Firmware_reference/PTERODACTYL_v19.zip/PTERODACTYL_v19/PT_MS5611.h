/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: Skript to control a MS5611 Pressure sensor

#ifndef PT_MS5611_H
#define PT_MS5611_H
#include <Arduino.h>

#define MS5611_ADDRESS                (0x77)

#define MS5611_CMD_ADC_READ           (0x00)
#define MS5611_CMD_RESET              (0x1E)
#define MS5611_CMD_CONV_D1            (0x40)
#define MS5611_CMD_CONV_D2            (0x50)
#define MS5611_CMD_READ_PROM          (0xA2)

typedef enum
{
    MS5611_ULTRA_HIGH_RES   = 0x08,
    MS5611_HIGH_RES         = 0x06,
    MS5611_STANDARD         = 0x04,
    MS5611_LOW_POWER        = 0x02,
    MS5611_ULTRA_LOW_POWER  = 0x00
} ms5611_osr_t;


/************************************************************************************************************************************************
Class Definition
************************************************************************************************************************************************/
class MS5611{
  public:
  
    bool begin(ms5611_osr_t osr = MS5611_ULTRA_HIGH_RES);
    uint32_t readRawTemperature(void);
    uint32_t readRawPressure(void);
    double readTemperature(uint32_t rawTemp, bool compensation = false);
    int32_t readPressure(uint32_t rawPress, uint32_t rawTemp, bool compensation = false);
    void setOversampling(ms5611_osr_t osr);
    ms5611_osr_t getOversampling(void);
    
    float tempC();
    float tempF();
    float pressurePSI();
    float pressureATM();
    float altitudeFt(float msPressurePSI);
    float altitudeM();
    bool status();
    void update();

    float msTemperatureC = 999;
    float msTemperatureF = 999;
    float msPressureMBar = 999;
    float msPressurePSI = 999;
    float msPressureATM = 999;
    float msAltitudeFt = 999;
    float msAltitudeM = 999;
    float msVertVelFt = 999;
    float msVertVelM = 999;

  private:
    
    uint16_t fc[6];
    uint8_t ct;
    uint8_t uosr;
    int32_t TEMP2;
    int64_t OFF2, SENS2;

    void reset(void);
    void readPROM(void);

    uint16_t readRegister16(uint8_t reg);
    uint32_t readRegister24(uint8_t reg);


    int _pin1;
    int _pin2;
    bool _status;
    
    double pressureBoundary1;
    double pressureBoundary2;
    double pressureBoundary3;
    float h1 = 36152.0;
    float h2 = 82345.0;
    float T1;
    float T2;
    float T3;

    float pressurePSF;

    double prevAltitudeFt;
    double prevTime;
};

#endif
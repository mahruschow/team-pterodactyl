/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This sketch is a LED Class that will allow any number of LEDs
//         to be controlled
// Mostly taken from: https://youtu.be/S_uaROFnWSg

#ifndef PT_LED_H
#define PT_LED_H
#include <Arduino.h>

/************************************************************************************************************************************************
LED Class Definition
************************************************************************************************************************************************/
class LED{
  public:
    LED(int pin);
    void begin();
    void on();
    void off();
    bool status();
  
  private:
    int _pin;
    bool _status;
    
};

#endif
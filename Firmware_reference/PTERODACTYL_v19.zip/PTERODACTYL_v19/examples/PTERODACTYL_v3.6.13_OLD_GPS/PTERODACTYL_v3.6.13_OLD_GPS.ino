/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
                  Seyon Wallo
                  Paul Wehling
                  Andrew Van Gerpen
      Modification Date: 1/12/23
************************************************/
//Purpose: Code for the PTERODACTYL Flight Computer

#include <PT_LED.h>          // Custom Library to use LED's
#include <PT_Thermistor.h>   // Custom Library to use Thermistors
#include <PT_OLED.h>         // Custom Library to use OLED
#include <PT_MS5611.h>       // Custom Library to use MS5611
#include <SparkFunLSM9DS1.h> // https://github.com/sparkfun/SparkFun_LSM9DS1_Arduino_Library
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h> // https://github.com/adafruit/Adafruit_BNO055
#include <utility/imumaths.h>
#include <TinyGPS++.h>
#include <UbloxGPS.h>        // https://github.com/MNSGC-Ballooning/FlightGPS/ 
#include <SoftwareSerial.h>  // All these Libraries are included with Arduino \/
#include <OneWire.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>  //// IF SD.h FOR THE ARDUINO IS IN YOUR LIBRARIES FOLDER THE CODE MIGHT NOT COMPILE ////
#include <XBee.h>

#define SERIAL_BAUD 115200           // When using arduino serial monitor, make sure baud rate is set to this same value
#define CHIP_SELECT BUILTIN_SDCARD   // Available for Teensy 3.5/3.6/4.0/4.1
#define SWITCH_PIN 30         
#define BUTTON_PIN 31 

bool currentSwitchStatus; // allows for wait until switch changes position to do something

// SD Logging
File datalog; // Constructed object that handles SD input and output, can input/output i.e read/write for multiple files
char dataFilename[ ] = "PTER00.csv"; //Make sure dataFileN matches first and second place of the zeros in terms of the arrays index
const byte dataFileN1 = 4; 
const byte dataFileN2 = 5; 
char oneHzFilename[ ] = "1HZ00.csv"; //Make sure dataFileN matches first and second place of the zeros in terms of the arrays index
const byte oneHzFileN1 = 3;
const byte oneHzFileN2 = 4;
char xbeeFilename[ ] = "XBA00.csv"; // 4th and 5th place so 3 & 4 in array terms
const byte xbeeFileC = 2; // Index of char that will be changed for each xbee, xbee 1 is A, xbee 2 is B, etc.
const byte xbeeFileN1 = 3;
const byte xbeeFileN2 = 4;
char xbeeSent[ ] = "SENT00.csv"; // 4th and 5th place so 3 & 4 in array terms
const byte xbeeSentN1 = 4;
const byte xbeeSentN2 = 5;
char xbeeBin[ ] = "XBin.csv"; // All non ID commands will be logged here.
char xbeeFilenames[10][3];   // Stores the values of 00 in the file name so that it can log the correct xbee to the correct file
bool sdStatus = false; // Status of datalog.begin();     
bool sdActive = false; // Status of if there are available file names i.e the SD could be full from files 0-100

// LEDs
LED LED1(LED_BUILTIN);
LED LED2(2); // Send pins that the LED's are using in class LED
LED LED3(3); // On the PCB the LED's are labled with the pins they're connected to on the Teensy
LED LED4(4); // LED 1 : Data Update : LED 2 : Switch On or Off
LED LED5(5); // LED 3 : SD Status   : LED 4 : XBee Update

// Thermistors
Thermistor ThermistorInt(40);   // Pins that the Thermistors are using in class Thermistor
Thermistor ThermistorExt(41);

// MS5611 Pressure Sensor
MS5611 MS5611; // Construct MS5611 Pressure Sensor object in class MS5611
bool msStatus = true; // will be changed in the set up

// IMU's
LSM9DS1 lsm;//                        id, I2C address, &Wire or &Wire1 or &Wire2
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire);
bool lsmStatus = false;
bool bnoStatus = false;
String imuType = "LSM";
float magnetometer[3] = {999, 999, 999};  // {x, y, z}
float accelerometer[3] = {999, 999, 999}; // {x, y, z}
float gyroscope[3] = {999, 999, 999};     // {x, y, z}
float orientation[3] = {999, 999, 999};   // {yaw (rotation about z axis), roll (rotation about y axis), pitch (rotation about x axis)}

//UBLOX M9n GPS
//access to TinyGPSPlus parser if needed
//TinyGPSPlus* FlightGPS::getParser() {return &parser;}
SoftwareSerial ss = SoftwareSerial(7,8); 
UbloxGPS gps = UbloxGPS(&ss);
String gpsType = "M9N";  // In order to output M9N to OLED to change between M9N & M8N
int gpsBaud = 39400;     // 9600 for M8N But that doesn't really matter since the code let's the user decide which gps to use
unsigned long gpsTimer = 0;

byte gpsStatus = 0;
//bool hpGPS = false;
int gpsMonth = 999;
int gpsDay = 999;
int gpsYear = 999;
int gpsHour = 999;
int gpsMinute = 999;
int gpsSecond = 999;
double gpsLat = 999;
double gpsLon = 999;
double gpsAltM = 999;
double gpsAltFt = 999;
double gpsGndSpeed = 999;
double gpsHeading = 999;
double gpsPDOP = 999;
byte SIV = 0;

// OLED
OLED OLED;   // Input the pins that the MS5611 is using
String strOLED, strOLED2;

//XBee Global Variables
SoftwareSerial XBeeSerial = SoftwareSerial(34, 35);  //Pins to communicate with XBee
XBee xbee(&XBeeSerial); //            DOUT RX  TX DIN
String channelID = "10";
String networkID = "A100";   // AAAA, BBBB, CCCCC, etc. change if there are multiple networks of xbees on the balloon fliight
int counterID = 0;          // Value of number of reciever xbees in the network, for reciever this will be set to the value in the ID

bool isRelay = false;
String xbeeMessage;
byte xbeeRate = 1;         // how many loops until it sends another data string
byte xbeeTimer = 1;        // xbeeRate - xbeeTimer = what loop the first command is sent on
byte xbeeTimerStart = 0;   // what number the loop starts at: should be 0
byte xbeeSendValue = 1;    // can be a different value than xbeeRate, then the xbee will send on that value of xbeeTimer but only every xbeeRate
byte numberOfXbees = 1;    // Total number of xbees on network
String xbeeID = "X1";        //Choose an ID for your XBee - 2-4 character string, A-Z and 0-9 with 1 at the end 
const byte indexOfIntID = 1; // Index of the 1 in at the end of the ID
const char inboxTerminator = '&'; // Make sure that not too much is being taken from the XBees inbox
const String IDterminator = "?";  // Make sure the ID can be taken out of recieved String
const String stringTerminator = "!"; // Make sure the code knows when a full string has been built

// Data Logging
String header = "T(h:m:s),FT(h:m:s),T(Sec),T(ms),UF(Hz),Sats,Date,Time,Lat,Lon,Alt(Ft),Alt(M),intT(C),intT(F),extT(C),extT(F),msTemp(C),msTemp(F),msPress(PSI),msPress(ATM),msAlt(ft),msAlt(M),VertVel(Ft/S),VertVel(M/S),mag x,mag y,mag z,accel x,accel y,accel z,gyro x,gyro y,gyro z,orien yaw,orien pitch,orien roll,xbee message";
String _print;

//Timer
String fullTimer = "NA:NA:NA";         // millis() turned into a flight timer String format, shouldn't read as N/A:N/A:N/A on serial monitor
unsigned long timer = 0;                  // Stored millis() value, used for dataDelay's soft pause
float timerSec = 0;                       // Stored millis() / 1000 value for seconds
unsigned int buttonTimer = 0;             // Soft Pause for button to send flip command

//Flight Timer
String flightTimerString = "NA:NA:NA"; // Initial value of flight timer, before flight starts, then outputs millis()-flightStartTime as flight timer String
unsigned long flightStartTime = 0;        // Value in millis of when the flight starts
bool flightTimerStatus = false;           // Status for if the flight starts
float altFtStart = 0;                     // Alt of the payload when the payload is turned on, is compared against current alt to start flight timer

//Code Delay Time milliseconds
const unsigned int dataDelay = 999;        // Delay inbetween every time updateData is called which updates the full data string and all onboard sensors
const unsigned int setupDelay = 499;      // If Setup commands are running too fast to see on the OLED increase this delay
const unsigned int xbeeDelay = 999;       // Delay inbetween every xbee 'ask' for data from reciever
unsigned long xbeeTimerSec;               // Stored value of millis() to compare against xbeeDelay
const unsigned int oneHzDelay = 999;      // Delay to store data every one sec / mainly useful for HP Code
unsigned long oneHzTimer;                 // Stored value of millis() to compare against oneHzDelay
const unsigned int oledDelay = 4999;      // Delay inbetween each oled screen switch
unsigned long oledTimer;                  // Stored value of millis() to compare against oledDelay
unsigned int oledCounter = 0;
unsigned int oledCounterMax = 4;

//Configuration Variables
char config[ ] = "Configuration.txt";
bool configStatus;
const unsigned int configDelay = 9999;    // Delay inbetween each oled screen switch
unsigned long configTimer;                // Stored value of millis() to compare against oledDelay
unsigned int configCounter = 0;           // Should be one less 


// updateFrequency function
unsigned long pastTime = 0;
float frequencyHz = 0;

String data = "No Data";

///////////////////////////////////////////////// SETUP /////////////////////////////////////////////////
void setup() {
  Serial.begin(SERIAL_BAUD); //define baud rate in variable decleration above
  Serial.println("Serial    Online!");

  LED1.begin(); // Initilize all LED's with class LED 
  LED2.begin();
  LED3.begin();
  LED4.begin();
  LED5.begin();

  LED1.on();
  
  pinMode(BUTTON_PIN, INPUT_PULLUP); // Initialize the momentary switch (push button) pin as an input, labled pin 31 on PCB
  pinMode(SWITCH_PIN, INPUT_PULLUP); // Initialize the switch pin as an input, labled 30 on PCB
  
  OLED.begin();
  OLED.update("Init...");
  wait(setupDelay); // Soft pause for when everything is online
  delay(300);

  _print = (sdSetup(dataFilename, dataFileN1, dataFileN2) && sdActive) ? "SD Card   Online! Creating File... Logging to: " + String(dataFilename) : (sdStatus) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  Serial.println(_print);
  _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(dataFilename) : (sdStatus) ? "NAFM\nClear SD\n\n\n\nSkip: B" : "SD\nFailed\n\n\n\nSkip: B";
  OLED.update(_print);
  if (!sdStatus || !sdActive) LED3.on();
  if (!sdStatus || !sdActive) while(!updateButtonStatus()) delay(20);
  wait(setupDelay);
  delay(500);
  _print = (sdSetup(oneHzFilename, oneHzFileN1, oneHzFileN2) && sdActive) ? "SD Card   Online! Creating File... Logging to: " + String(oneHzFilename) : (sdStatus) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  Serial.println(_print);
  _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(oneHzFilename) : (sdStatus) ? "NAFM\nClear SD\n\n\n\nSkip: B" : "SD\nFailed\n\n\n\nSkip: B";
  OLED.update(_print);
  if (!sdStatus || !sdActive) LED3.on();
  if (!sdStatus || !sdActive) while(!updateButtonStatus()) delay(20);
  wait(setupDelay);
  delay(500);
  
  while (ThermistorInt.getStatus() == 0 || ThermistorExt.getStatus() == 0){
      if(millis()-timer > 250){
          _print = (ThermistorInt.begin(12) && ThermistorExt.begin(12)) ? "Therm Int Online!\nTherm Ext Online!" : ThermistorInt.getStatus() ? "Therm Int Online!\nTherm Ext Offline...Skip: B\nRetry: S" : ThermistorExt.getStatus() ? "Therm Int Offline...\nTherm Ext Online!\nSkip: B\nRetry: S" : "Therm Int Offline...Therm Ext Offline...Skip: B\nRetry: S";
          Serial.println(_print);  // Since this is a Teensy we are using, the read bit resolution can be at a max of 13 (12 for Teensy 4.1).
          OLED.update(_print);     // The maximum adc value given to the thermistor, should be 8191 (2^13) for a Teensy 3.6, 
          timer = millis();        // 4095 (2^12) for a Teensy 4.1, and 1023 (2^10) for an Arduino
      }
      if(ThermistorInt.getStatus() == 0 || ThermistorExt.getStatus() == 0) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
  }
  wait(setupDelay);
  delay(300);

  configTimer = millis();
  OLED.update("Using New\nConfig?\nYes: S on+No: S off\n\nPress B");
  Serial.println("Using New Configuration on the PTERODACTYL Hardware?   Yes: Switch on   No: Switch off   Press Button to continue");
  while (updateButtonStatus() == 0 && millis() - configTimer < configDelay) {
      if(updateSwitchStatus()){
          LED3.on();
          LED5.off();
          configStatus = true;
          OLED.update("Using New\nConfig?\nYes: S on+No: S off\n\nPress B");
      }
      if(!updateSwitchStatus()){
          LED5.on();
          LED3.off();
          configStatus = false;
         OLED.update("Using New\nConfig?\nYes: S on\nNo: S off+\nPress B");
      }
      delay(20);
  }
  if (millis() - configTimer > configDelay){
    configStatus = false;
  }
  //Serial.println(configStatus);
  LED5.off();
  LED3.off();
  delay(250);
  if (!configStatus){
    datalog = SD.open(config);
    if(!datalog.available()) {
      configStatus = true;
    }
    else{
      if (datalog) {
      //Serial.print("Reading ...");
      //Serial.println(filename);
      String str = "";
      String fullString = "";
        while (datalog.available()) {
          str = datalog.read();
          //Serial.println(str);
          //integer = str.toInt();
          fullString += str;
            if (str == "\n") {
              configCounter++;
              if(configCounter == 1) msStatus = fullString.toInt();
              else if(configCounter == 2) imuType = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 3) lsmStatus = fullString.toInt();
              else if(configCounter == 4) bnoStatus = fullString.toInt();
              else if(configCounter == 5) gpsType = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 6) gpsBaud = fullString.toInt();
              else if(configCounter == 7) channelID = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 8) networkID = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 9) isRelay = fullString.toInt();
              else if(configCounter == 10) counterID = fullString.toInt();
              //Serial.print(fullString);
              //Serial.print(" ");
              //Serial.println(configCounter);
              fullString = "";
            }
        }
      }
    }
    datalog.close();
  }
  else {
    SD.remove(config); //Delete all data from config file
    //datalog.close();
  }

  if(!configStatus){
    Serial.print("MS5611       "); Serial.println(msStatus);
    Serial.print("IMU Type     "); Serial.println(imuType);
    Serial.print("LSM Status   "); Serial.println(lsmStatus);
    Serial.print("BNO Status   "); Serial.println(bnoStatus);
    Serial.print("GPS Type     "); Serial.println(gpsType);
    Serial.print("GPS Baud     "); Serial.println(gpsBaud);
    Serial.print("Channel      "); Serial.println(channelID);
    Serial.print("Network      "); Serial.println(networkID);
    Serial.print("Relay        "); Serial.println(isRelay);
    Serial.print("XBee Counter "); Serial.println(counterID);
  }

  if(configStatus){
      OLED.update("Using\nMS5611?\nYes: S on+No: S off\n\nPress B");
      Serial.println("Using MS5611   Yes: Switch on   No: Switch off   Press Button to continue");
      while (updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              msStatus = true;
              OLED.update("Using\nMS5611?\nYes: S on+No: S off\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              msStatus = false;
            OLED.update("Using\nMS5611?\nYes: S on\nNo: S off+\nPress B");
          }
          delay(20);
      }
      logData(String(msStatus), config);  // Log data to SD

      LED5.off();
      LED3.off();
      delay(250);
  }

  _print = (msStatus && MS5611.begin()) ? "MS5611    Online!" : "MS5611    Offline...\nSkip: B";
  Serial.println(_print);
  OLED.update(_print);
  if (msStatus) MS5611.update();
  while (!msStatus && !updateButtonStatus()) delay(20); 
  if (msStatus) altFtStart = MS5611._altitudeFt;
  wait(setupDelay);
  delay(300);
  
  if(configStatus){
      OLED.update("IMU Type:\nLSM: S on\nBNO:S off\n\n\nPress B");
      Serial.println("IMU Type:   LSM: Switch On   BNO: Switch Off   Press Button to Continue");
        while (updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              imuType = "LSM";
              lsmStatus = true;
              bnoStatus = false;
              OLED.update("IMU Type:\nLSM: S on+BNO:S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              imuType = "BN0";
              lsmStatus = false;
              bnoStatus = true;
              OLED.update("IMU Type:\nLSM: S on\nBNO:S off+\n\nPress B");
          }
          delay(20);
      }
      logData(imuType, config);  // Log data to SD
      logData(String(lsmStatus), config);  // Log data to SD
      logData(String(bnoStatus), config);  // Log data to SD
      LED3.off();
      LED5.off();
      delay(150);
  }

  if(lsmStatus){
      lsmStatus = false;
      while(!lsmStatus){
          lsmStatus = (lsm.begin()) ? true : false;
          _print = (lsmStatus) ? "LSM9DS1   Online!" : "LSM9DS1   Offline...\nSkip: B\nRetry: S";
          Serial.println(_print);
          OLED.update(_print);
          if (lsmStatus) break;
          while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
          if (updateButtonStatus()) break;
          delay(100);
      }
  }
  else if(bnoStatus){
      bnoStatus = false;
      while(!bnoStatus){
          bnoStatus = (bno.begin()) ? true : false;
          _print = (bnoStatus) ? "BNO055    Online!" : "BNO055    Offline...\nSkip: B\nRetry: S";
          Serial.println(_print);
          OLED.update(_print);
          if (bnoStatus) break;
          while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
          if (updateButtonStatus()) break;
          delay(100);
      }
  }
  wait(setupDelay);
  delay(300);

  if(configStatus){
      OLED.update("GPS Type:\nM9: S on\nM8: S off\n\n\nPress B");
      Serial.println("GPS Type:   M9N: Switch On   M8N: Switch Off   Press Button to Continue");
      while(updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              gpsType = "M9";
              gpsBaud = 39400;
              OLED.update("GPS Type:\nM9: S on +M8: S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              gpsType = "M8";
              gpsBaud = 9600;
              OLED.update("GPS Type:\nM9: S on\nM8: S off+\n\nPress B");
          }
          delay(20);
      }
      logData(gpsType, config);  // Log data to SD
      logData(String(gpsBaud), config);  // Log data to SD
      LED5.off();
      LED3.off();
      delay(300);
  }

  while(gpsStatus != 1){
      _print = (gpsSetup() == 1) ? gpsType + " GPS    Online!" : gpsType + " GPS    Offline...\nSkip: B\nRetry: S";
      Serial.println(_print);
      OLED.update(_print);
      if(gpsStatus != 1) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
      delay(20);
  }
  //}
  wait(setupDelay);
  delay(400);

  //pinMode(27, OUTPUT);
  //delay(20);
  //digitalWrite(27, LOW);
  
  OLED.update("\n\n   XBee\n   Setup");
  _print = (xBeeSetup()) ? "XBee      Relay..." : "XBee      Reciever..";
  Serial.println(_print);
  OLED.update(_print);
  wait(setupDelay);
  delay(300);

  logData(header, dataFilename);
  logData(header, oneHzFilename);
  Serial.println(header);
  LED1.off();
  oledTimer = millis();
  //digitalWrite(27, HIGH);  // turn the RST on HIGH for flow control
}

///////////////////////////////////////////////// LOOP /////////////////////////////////////////////////
void loop() {
  //if(millis()-gpsTimer > 20 && !hpGPS){
      gps.update(); // The structure of this loop is to ensure that the button, switch, GPS, and XBee all work properly
      //while (ss.available()) {
        //ss.parser.encode(ss.read());
      //}
      //gpsTimer = millis();
  //}

  if (updateButtonStatus()) LED5.on();
  else LED5.off();

  if (updateSwitchStatus()) { 
      LED3.on();
      oledTimer = millis();
  }
  else LED3.off();

  listenXBee();

  if (updateButtonStatus() && millis() - buttonTimer > 250) { // Check if the button is pressed to send command.
      updateXBee("FLIP");                                     // Only soft pause that can use buttonTimer in loop
      buttonTimer = millis();
      oledCounter++;
      if (oledCounter == oledCounterMax) oledCounter = 0;
      oledTimer = millis();
  }

  if(millis() - oledTimer > oledDelay) { // Only soft pause that can use timer in loop
    oledTimer = millis();
    oledCounter++;
    if (oledCounter == oledCounterMax) oledCounter = 0;
  }
  
  if(millis() - timer > dataDelay) { // Only soft pause that can use timer in loop
      timer = millis();
      updateData();
  }

  if(millis() - oneHzTimer > oneHzDelay) { // Log data at 1 Hz to 1HZ file
      oneHzTimer = millis();
      logData(data, oneHzFilename);
  }

  if(millis() - xbeeTimerSec > xbeeDelay && isRelay) { // Send an ask for data to the reciever units in hopes of recieving a data string
      if (xbeeRate != 0) updateXBee(xbeeID.substring(0, indexOfIntID) + String(xbeeTimer) + IDterminator + "DATA" + stringTerminator + String(inboxTerminator));       // Send XBee data every XBee send value times, allows for multiple devices to send on different values of xbeeTimer
      if (xbeeTimer >= xbeeRate) xbeeTimer = xbeeTimerStart;  // Reset  xbeeTimer when xbeeRate is reached
      if (xbeeRate != 0) xbeeTimer++;
      xbeeTimerSec = millis();
      //while(XBeeSerial.available() == 0 && millis() - xbeeTimerSec < (xbeeDelay/2)) listenXBee();
  }

}

////////////////////////////////////////////// Functions ///////////////////////////////////////////////
// void wait(unsigned const int); 
// void updateButtonStatus();
// void updateSwitchStatus();
// bool sdSetup(char *dataFile, byte const &N1, byte const &N2);
// void logData(String const &Data, char const *dataFile);
// bool gpsSetup();
// void updateGPS();
// void updateIMU();
// void printEvent(sensors_event_t*);
// void updateBNO();
// String flightTimeStr(unsigned long);
// float updateFrequency(unsigned long _time);
// void updateData();

void wait(unsigned const int t){ //Soft pause placed in code
  while(millis() - timer <= t) {}
  timer = millis();
}

bool updateButtonStatus(){ 
  bool buttonStatus = false;
  buttonStatus = (digitalRead(BUTTON_PIN) == 0) ? true : false;
  return buttonStatus;
}

bool updateSwitchStatus(){
  bool switchStatus = false;
  switchStatus = (digitalRead(SWITCH_PIN) == 0) ? true : false;
  return switchStatus;
}

bool sdSetup(char *dataFile, byte const &N1, byte const &N2){
  pinMode(CHIP_SELECT,OUTPUT);
  if(!SD.begin(CHIP_SELECT)) sdStatus = 0;
  else {
      sdStatus = 1;
      for (byte i = 0; i < 100; i++) {
          dataFile[N1] = '0' + i/10; 
          dataFile[N2] = '0' + i%10;
          if (!SD.exists(dataFile)) {
             datalog = SD.open(dataFile, FILE_WRITE);
              sdActive = true;
              break;
          }
          else sdActive = false;
      }
  } 
  return sdStatus;
}

void logData(String const &Data, char const *dataFile){
  datalog = SD.open(dataFile, FILE_WRITE);
  datalog.println(Data);
  datalog.close();
}

bool gpsSetup(){
  LED2.on();
  OLED.update("\nGPS\n\nSetup");
  ss.begin(gpsBaud);
  //gps.init();
  
  for (byte i=0; i<=50; i++){ // Attempt to set GPS to Airborn mode 50 times
      if (gps.setAirborne()) {
          gpsStatus = 1;
          break;
      }
      if (i==50) gpsStatus = 0;
  }
  LED2.off();
  return gpsStatus;
}
void updateGPS(){ // Update all values for M9N or M8 GPS
  gpsMonth = gps.getMonth();
  gpsDay = gps.getDay();
  gpsYear = gps.getYear();
  gpsHour = gps.getHour() - 5;  // Their time zone is 5h ahead
  gpsMinute = gps.getMinute();
  gpsSecond = gps.getSecond();
  gpsLat = gps.getLat();
  gpsLon = gps.getLon();
  gpsAltM = gps.getAlt_meters();
  gpsAltFt = gps.getAlt_feet();
  SIV = gps.getSats();
}

void updateIMU(){ // Update the Mag, Acc, and Gyro on the LSM9DS1
  if(lsm.gyroAvailable()) lsm.readGyro();
  if(lsm.accelAvailable()) lsm.readAccel();
  if(lsm.magAvailable()) lsm.readMag();

  magnetometer[0] = lsm.calcMag(lsm.mx);
  magnetometer[1] = lsm.calcMag(lsm.my);
  magnetometer[2] = lsm.calcMag(lsm.mz);
  accelerometer[0] = lsm.calcAccel(lsm.ax);
  accelerometer[1] = lsm.calcAccel(lsm.ay);
  accelerometer[2] = lsm.calcAccel(lsm.az);
  gyroscope[0] = lsm.calcGyro(lsm.gx);
  gyroscope[1] = lsm.calcGyro(lsm.gy);
  gyroscope[2] = lsm.calcGyro(lsm.gz);
}

void printEvent(sensors_event_t* event) {
  if (event->type == SENSOR_TYPE_ACCELEROMETER) {
      accelerometer[0] = (float)event->acceleration.x;
      accelerometer[1] = (float)event->acceleration.y;
      accelerometer[2] = (float)event->acceleration.z;
  }
  else if (event->type == SENSOR_TYPE_ORIENTATION) {
      orientation[0] = (float)event->orientation.x;
      orientation[1] = (float)event->orientation.y;
      orientation[2] = (float)event->orientation.z;
  }
  else if (event->type == SENSOR_TYPE_MAGNETIC_FIELD) {
      magnetometer[0] = (float)event->magnetic.x;
      magnetometer[1] = (float)event->magnetic.y;
      magnetometer[2] = (float)event->magnetic.z;
  }
  else if (event->type == SENSOR_TYPE_GYROSCOPE) {
      gyroscope[0] = (float)event->gyro.x;
      gyroscope[1] = (float)event->gyro.y;
      gyroscope[2] = (float)event->gyro.z;
  }
}

void updateBNO(){
  //could add VECTOR_ACCELEROMETER, VECTOR_MAGNETOMETER, VECTOR_GRAVITY...
  sensors_event_t orientationData, angVelocityData, magnetometerData, accelerometerData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  bno.getEvent(&angVelocityData, Adafruit_BNO055::VECTOR_GYROSCOPE);
  bno.getEvent(&magnetometerData, Adafruit_BNO055::VECTOR_MAGNETOMETER);
  bno.getEvent(&accelerometerData, Adafruit_BNO055::VECTOR_ACCELEROMETER);

  accelerometer[0] = (float)accelerometerData.acceleration.x;
  accelerometer[1] = (float)accelerometerData.acceleration.y;
  accelerometer[2] = (float)accelerometerData.acceleration.z;
  orientation[0] = (float)orientationData.orientation.x;
  orientation[1] = (float)orientationData.orientation.y;
  orientation[2] = (float)orientationData.orientation.z;
  magnetometer[0] = (float)magnetometerData.magnetic.x;
  magnetometer[1] = (float)magnetometerData.magnetic.y;
  magnetometer[2] = (float)magnetometerData.magnetic.z;
  gyroscope[0] = (float)angVelocityData.gyro.x;
  gyroscope[1] = (float)angVelocityData.gyro.y;
  gyroscope[2] = (float)angVelocityData.gyro.z;

  uint8_t system, gyro, accel, mag = 0;
  bno.getCalibration(&system, &gyro, &accel, &mag);
}

String flightTimeStr(unsigned long t) { // Turns a time in seconds to a usable string for print statements  
  String fTime = "";                    // Format: "00:00:00" -> h:m:s
  fTime += (String(t / 3600) + ":");
  t %= 3600;
  fTime += String(t / 600);
  t %= 600;
  fTime += (String(t / 60) + ":");
  t %= 60;
  fTime += (String(t / 10) + String(t % 10));
  return fTime;
}

float updateFrequency(unsigned long _time){
  float frequency = 1.0 / ((_time - pastTime)/1000.0);
  pastTime = _time;
  return frequency;
}

void updateData(){
  LED2.on();
  timerSec = (timer * 1.0) / 1000.0;
  fullTimer = flightTimeStr(timerSec);
  frequencyHz = updateFrequency(timer);

  if (ThermistorInt.getStatus()) ThermistorInt.update();
  if (ThermistorExt.getStatus()) ThermistorExt.update();
  if (msStatus) MS5611.update();
  if (lsmStatus) updateIMU();
  if (bnoStatus) updateBNO();
  if (gpsStatus == 1) updateGPS();

  if (msStatus){
      if (MS5611._altitudeFt - altFtStart > 100 && !flightTimerStatus) {
          flightStartTime = timerSec;
          flightTimerStatus = true;
      }
      if (flightTimerStatus) flightTimerString = flightTimeStr(int(timerSec) - flightStartTime);
  }
  // Data String Assembly
  data = fullTimer + "," + flightTimerString + "," + String(timerSec, 1) + "," + String(millis()) + "," + String(frequencyHz, 1) + "," +

  String(SIV) + "," + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + "," +
  String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond) + "," +
  String(gpsLat, 6) + "," + String(gpsLon, 6) + "," + String(gpsAltFt) + "," + String(gpsAltM) + "," + 
  
  String(ThermistorInt.getTempC()) + "," + String(ThermistorInt.getTempF()) + "," + String(ThermistorExt.getTempC()) + "," + String(ThermistorExt.getTempF()) + "," + 
  
  String(MS5611.msTemperatureC) + "," + String(MS5611.msTemperatureF) + "," + String(MS5611.msPressurePSI) + "," + String(MS5611.msPressureATM) + "," + 
  String(MS5611._altitudeFt) + "," + String(MS5611._altitudeM) + "," + String(MS5611.vertVelFt) + "," + String(MS5611.vertVelM) + "," +

  String(magnetometer[0]) + "," + String(magnetometer[1]) + "," + String(magnetometer[2]) + "," +
  String(accelerometer[0]) + "," + String(accelerometer[1]) + "," + String(accelerometer[2]) + "," +
  String(gyroscope[0]) + "," + String(gyroscope[1]) + "," + String(gyroscope[2]) + "," +
  String(orientation[0]) + "," + String(orientation[2]) + "," + String(orientation[1]);

  data = data  + "," +  String(xbeeMessage); 
  xbeeMessage = "";                             // Data String Assembly end

  if(oledCounter == 0){ // OLED Assembly Start
    strOLED = String(gpsLat,4) + "\n" + String(gpsLon,4) + "\n" + String(gpsAltFt, 2) + "ft\n";
    strOLED += String(SIV);
    strOLED2 = String(SIV);
    for(int i=strOLED2.length(); i<3; i++){
        strOLED += " ";
    }
    strOLED += "SIV " + String(frequencyHz, 1) + "I:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI";
    OLED.update(strOLED);
  }
  
  else if(oledCounter == 1){
    strOLED = "Y " + String(orientation[0]) + "\nP " + String(orientation[2]) + "\nR " + String(orientation[1]) + "\n";
    strOLED += String(SIV);
    strOLED2 = String(SIV);
    for(int i=strOLED2.length(); i<3; i++){
        strOLED += " ";
    }
    strOLED += "SIV " + String(frequencyHz, 1) + "I:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI";
    OLED.update(strOLED);
  }
  
  else if(oledCounter == 2){
    OLED.update(String(dataFilename) + String(xbeeFilename) + "\nC" + channelID + " N:" + networkID + "ID:" + String(xbeeID) + " XT:" + String(xbeeTimer) + "I:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI");
  }

  else if(oledCounter == 3){
    strOLED = fullTimer + "\n" + flightTimerString + "\n" + String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond) + "\n" + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear);
    strOLED2 = String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear);
    for(int i=strOLED2.length(); i<10; i++){
        strOLED += " ";
    }
    strOLED += String(MS5611._altitudeFt, 1) + " ft\n";
    strOLED += String(MS5611.msTemperatureF) + " F";
    OLED.update(strOLED);
  }

  //OLED.update(String(ecefX, 0) + " X\n" + String(ecefY, 0) + "Y\n" + String(ecefZ, 0) + " Z\n" + String(SIV) + " Sats\nInt:" + String(int(ThermistorInt.getTempF())) + " F\n" + String(MS5611.msPressurePSI,2) + " PSI");

  logData(data, dataFilename);  // Log data to SD
  //Serial.println("(h:m:s),FlightT,sec,Sat,Date,GPSTime,GPSLat   ,GPSLon.   ,Alt(Ft),Alt M,ECEF X ,ECEF Y  ,ECEF Z ,Zo#,Easting,Northing,GndSpd(m/s),Head(deg),PDOP,intT(C),intT(F),extT(C),extT(F),msTemp(C),msTemp(F),msPress(PSI),msPress(ATM),msAlt(ft),msAlt(M),VertVel(Ft/S),VertVel(M/S),mag x,mag y,mag z,accel x,accel y,accel z,gyro x,gyro y,gyro z,orien yaw,orien pitch,orien roll,xbee message");
  Serial.println(data); // Serial Print data
  LED2.off(); 
}
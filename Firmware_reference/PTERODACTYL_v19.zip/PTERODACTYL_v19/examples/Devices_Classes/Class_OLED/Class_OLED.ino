/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: Class to control an OLED display

/* //Libraries included in the OLED.h library

#include <Wire.h>
#include <OneWire.h>
#include <SFE_MicroOLED.h>  // https://github.com/sparkfun/SparkFun_Micro_OLED_Arduino_Library

#define PIN_RESET 9
#define DC_JUMPER 1

MicroOLED oled(PIN_RESET, DC_JUMPER);    // I2C declaration

************************************************************************************************************************************************
LED Class Definition
************************************************************************************************************************************************
class OLED{
  public:
    void begin();
    void update(String disp);
  
  private:
    int _pin1;
    int _pin2;
};

************************************************************************************************************************************************
LED Member Defenition
************************************************************************************************************************************************
void OLED::begin(){ // this initializes the OLED
  Wire.begin();
  oled.begin();    // Initialize the OLED
  oled.clear(ALL); // Clear the display's internal memory
  oled.display();  // Display what's in the buffer (splashscreen)
  oled.clear(PAGE); // Clear the buffer.

  randomSeed(analogRead(A0) + analogRead(A1));
  
}

void OLED::update(String disp){ //displays a string
  oled.clear(PAGE);
  oled.setFontType(0);
  oled.setCursor(0, 0);
  oled.println(disp);
  oled.display();
}

************************************************************************************************************************************************
Arduino Sketch Start
************************************************************************************************************************************************/

#include <PT_OLED.h>  // class is inside this library

OLED OLED;


void setup() {
  // put your setup code here, to run once:
  OLED.begin();
  OLED.update("Init...");
  delay(500);

}

void loop() {
  // put your main code here, to run repeatedly:
  OLED.update("Hello\nWorld!");
  delay(500);
  
}

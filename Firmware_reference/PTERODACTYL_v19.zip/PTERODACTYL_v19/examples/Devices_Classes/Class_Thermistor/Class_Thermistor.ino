/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This Sketch will allow any number of Thermistors 
//         to be controlled frictionlessly

/***********************************************************************************************************************************************
Class Definition
************************************************************************************************************************************************
class Thermistor{
  public:
    Thermistor(int pin);
    bool begin(int analogResolutionBits);
    bool updateStatus();
    bool getStatus();
    float getTempC();
    float getTempF();
    void update();
    
  private:
    int _pin;
    int _analogResolutionBits;
    float adcMax; // The maximum adc value given to the thermistor
    float A = 0.001125308852122;   // A, B, and C are constants used for a 10k resistor and 10k thermistor for the steinhart-hart equation
    float B = 0.000234711863267;
    float C = 0.000000085663516; 
    float R1 = 10000; // 10k Ω resistor
    float Tinv;
    float adcVal;
    float logR;
    float T; // these three variables are used for the calculation from adc value to temperature
    float currentTempC = 999; // The current temperature in Celcius
    float currentTempF = 999; // The current temperature in Fahrenheit
    bool _status = false;
};

************************************************************************************************************************************************
Member Defenition
************************************************************************************************************************************************
Thermistor::Thermistor(int pin){  // constructor
  _pin = pin; // here is where the pin you want to use is stored within the class DigitalLED
}

bool Thermistor::begin(int analogResolutionBits){ // this initializes the pin
  analogReadResolution(analogResolutionBits);  // this value should be
  _analogResolutionBits = analogResolutionBits;
  return updateStatus();
}

bool Thermistor::updateStatus(){
  _status = (currentTempF > -80 && currentTempF < 160) ? true : false;
  return _status;
}

bool Thermistor::getStatus(){
  return _status;
}

float Thermistor::getTempC(){ // reads the temperature but the output value is in Celsius
  return currentTempC;
}

float Thermistor::getTempF(){ // reads the temperature but the output value is in Farenheit
  return currentTempF;
}

void Thermistor::update(){
  analogReadResolution(_analogResolutionBits);
  adcMax = pow(2, _analogResolutionBits)-1.0;
  adcVal = analogRead(_pin);
  logR = log(((adcMax/adcVal)-1)*R1);
  Tinv = A+B*logR+C*logR*logR*logR;
  T = 1/Tinv;
  currentTempC = T-273.15; // converting to celcius
  currentTempF = currentTempC*9/5+32;
}

************************************************************************************************************************************************
Arduino Sketch Start
************************************************************************************************************************************************/

#include <PT_Thermistor.h>      // The class above is inside this library

#define SERIAL_BAUD 115200       // when using arduino serial monitor, make sure baud rate is set to this same value

Thermistor ThermistorInt(40);   // Define the pin the Thermistor is on as an int
Thermistor ThermistorExt(41);

String header = "intT(C),intT(F),extT(C),extT(F)"; 
String data = "No Data";
String _print;
int timer;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(SERIAL_BAUD); // define baud rate in variable decleration above
  Serial.println("Serial Online...");

  //ThermistorInt.begin(12); // Since this is a Teensy we are using, the read bit resolution can be at a max of 13 (12 for Teensy 4.1).
  //ThermistorExt.begin(12); // The maximum adc value given to the thermistor, should be 8191 (2^13) for a Teensy 3.6, 
                             // 4095 (2^12) for a Teensy 4.1, and 1023 (2^10) for an Arduino

  _print = (ThermistorInt.begin(12) && ThermistorExt.begin(12)) ? "Therm Int Online...\nTherm Ext Online..." : ThermistorInt.getStatus() ? "Therm Int Online...\nTherm Ext Offline..." : ThermistorExt.getStatus() ? "Therm Int Offline...\nTherm Ext Online...\nSkip: B" : "Therm Int Offline...\nTherm Ext Offline...";
  
  Serial.println(_print);
  delay(1000); 
}

void loop() {
  // put your main code here, to run repeatedly:
  if (millis() - timer > 500){
    if (ThermistorInt.getStatus()) ThermistorInt.update();
    if (ThermistorExt.getStatus()) ThermistorExt.update();
    data = String(ThermistorInt.getTempC()) + "," + String(ThermistorInt.getTempF()) + "," + String(ThermistorExt.getTempC()) + "," + String(ThermistorExt.getTempF());
  
    Serial.println();
    Serial.println(header);
    Serial.println(data);
    timer = millis();
  }
  
}

/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This sketch is a Library that will help teach about the
//         creation of libraries

#include <my_library.h>

void setup() {
  Serial.begin(9600);
  int result = addTwoInts(4,3);
  Serial.println(result);
}

void loop() {}

#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

/* This driver uses the Adafruit unified sensor library (Adafruit_Sensor),
   which provides a common 'type' for sensor data and some helper functions.

   To use this driver you will also need to download the Adafruit_Sensor
   library and include it in your libraries folder.

   You should also assign a unique ID to this sensor for use with
   the Adafruit Sensor API so that you can identify this particular
   sensor in any data logs, etc.  To assign a unique ID, simply
   provide an appropriate value in the constructor below (12345
   is used by default in this example).

   Connections
   ===========
   Connect SCL to analog 5
   Connect SDA to analog 4
   Connect VDD to 3.3-5V DC
   Connect GROUND to common ground

   History
   =======
   2015/MAR/03  - First release (KTOWN)
*/

/* Set the delay between fresh samples */
uint16_t BNO055_SAMPLERATE_DELAY_MS = 100;

// Check I2C device address and correct line below (by default address is 0x29 or 0x28)
//                                   id, address
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire);

//BNO IMU
float magnetometerBNO[3] = {999, 999, 999}; // {x, y, z}
float accelerometerBNO[3] = {999, 999, 999}; // {x, y, z}
float gyroscopeBNO[3] = {999, 999, 999}; // {x, y, z}
float orientationBNO[3] =  {999, 999, 999}; // {x, y, z}
float BNOTempC;

void setup(void)
{
  Serial.begin(115200);
  Serial.println("Orientation Sensor Test"); Serial.println("");

  /* Initialise the sensor */
  if (!bno.begin())
  {
    /* There was a problem detecting the BNO055 ... check your connections */
    Serial.print("Ooops, no BNO055 detected ... Check your wiring or I2C ADDR!");
    while (1);
  }

  delay(1000);
}

void loop(void)
{
  //could add VECTOR_ACCELEROMETER, VECTOR_MAGNETOMETER,VECTOR_GRAVITY...
  sensors_event_t orientationData , angVelocityData , linearAccelData, magnetometerData, accelerometerData, gravityData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  bno.getEvent(&angVelocityData, Adafruit_BNO055::VECTOR_GYROSCOPE);
  bno.getEvent(&linearAccelData, Adafruit_BNO055::VECTOR_LINEARACCEL);
  bno.getEvent(&magnetometerData, Adafruit_BNO055::VECTOR_MAGNETOMETER);
  bno.getEvent(&accelerometerData, Adafruit_BNO055::VECTOR_ACCELEROMETER);
  bno.getEvent(&gravityData, Adafruit_BNO055::VECTOR_GRAVITY);

  printEvent(&orientationData);
  printEvent(&angVelocityData);
  printEvent(&linearAccelData);
  printEvent(&magnetometerData);
  printEvent(&accelerometerData);
  printEvent(&gravityData);

  int8_t boardTemp = bno.getTemp();
  BNOTempC = (float)boardTemp;

  //uint8_t system, gyro, accel, mag = 0;
  //bno.getCalibration(&system, &gyro, &accel, &mag);

  Serial.println(
  String(magnetometerBNO[0]) + "," + String(magnetometerBNO[1]) + "," + String(magnetometerBNO[2]) + "," +
  String(accelerometerBNO[0]) + "," + String(accelerometerBNO[1]) + "," + String(accelerometerBNO[2]) + "," +
  String(gyroscopeBNO[0]) + "," + String(gyroscopeBNO[1]) + "," + String(gyroscopeBNO[2]) + "," +
  String(orientationBNO[0]) + "," + String(orientationBNO[1]) + "," + String(orientationBNO[2]) + "," +
  String(BNOTempC));
  delay(BNO055_SAMPLERATE_DELAY_MS);
}

void printEvent(sensors_event_t* event) {
    if (event->type == SENSOR_TYPE_ACCELEROMETER) {
    accelerometerBNO[0] = (float)event->acceleration.x;
    accelerometerBNO[1] = (float)event->acceleration.y;
    accelerometerBNO[2] = (float)event->acceleration.z;
  }
  else if (event->type == SENSOR_TYPE_ORIENTATION) {
    orientationBNO[0] = (float)event->orientation.x;
    orientationBNO[1] = (float)event->orientation.y;
    orientationBNO[2] = (float)event->orientation.z;
  }
  else if (event->type == SENSOR_TYPE_MAGNETIC_FIELD) {
    magnetometerBNO[0] = (float)event->magnetic.x;
    magnetometerBNO[1] = (float)event->magnetic.y;
    magnetometerBNO[2] = (float)event->magnetic.z;
  }
  else if (event->type == SENSOR_TYPE_GYROSCOPE) {
    gyroscopeBNO[0] = (float)event->gyro.x;
    gyroscopeBNO[1] = (float)event->gyro.y;
    gyroscopeBNO[2] = (float)event->gyro.z;
  }
}

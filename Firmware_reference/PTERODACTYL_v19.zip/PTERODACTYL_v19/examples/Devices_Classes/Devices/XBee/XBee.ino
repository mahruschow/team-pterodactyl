/*   Code to control the activity of an LED via xBee communication and transmit basic data back
 *   Author: Ryan Bowers
 *   For use with Introduction to Arduino Activity 10
 */

#include <SoftwareSerial.h>
#include <XBee.h>

#define LED_PIN 2
#define RELAY_PIN 30
#define BUTTON_PIN 31

String ID = "123";   //Choose an ID for your XBee - 2-4 character string, A-Z and 0-9 only please

SoftwareSerial xBee_ser = SoftwareSerial(34,35);  //Pins to communicate with xBee
XBee xBee = XBee(&xBee_ser);           //XBee object - connect to serial line

unsigned int numberOn = 0;  //variables to track system activity
unsigned long timeOn = 0, turnedOn;
bool isOn = false;
bool relay = false;

String buttonStatus;

void setup() {
  pinMode(RELAY_PIN, INPUT_PULLUP);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  xBee_ser.begin(XBEE_BAUD);
  if (digitalRead(RELAY_PIN) == LOW) {     //ground pin 7 before startup to put the Arduino in Relay Mode
    relay = true;
    xBee.enterATmode();       //Configure XBee as a relay
    xBee.atCommand("ATDL1");
    xBee.atCommand("ATMY0");
    xBee.exitATmode();

    Serial.begin(9600);                 //Open the Serial line to the computer
    Serial.println("Relay Mode active");  //Tell user that this was done successfully
  }
  else {
    pinMode(LED_PIN, OUTPUT);
    xBee.enterATmode();      //Configure XBee as a reciever
    xBee.atCommand("ATDL0"); //The DL and MY values of XBees that talk to each other should be inverted
    xBee.atCommand("ATMY1"); //Note how these are the reverse of the above settings for the relay unit
    xBee.exitATmode();

    Serial.begin(9600);
    Serial.println("Reciever Mode active");
  }
  xBee.setTimeout(100);
  xBee_ser.setTimeout(100);
}

void loop() {
  //Loop for relay system
  buttonStatus = (digitalRead(BUTTON_PIN)) ? "Off" : "On";
  //Serial.println(buttonStatus);

   // check if the pushbutton is pressed. If it is, the buttonState is HIGH:
  if (buttonStatus == "On") {
    xBee.print("FLIP");
    delay(500);
  }
  
  if (relay) {
    //Just pipe data from computer to xBee and vice versa (ignore xBee object)
    while (Serial.available() > 0) {
      String com = Serial.readStringUntil('\n');
      Serial.println(com);
      xBee_ser.print(com);
    }
    while (xBee_ser.available() > 0) {
      Serial.println(xBee_ser.readString() + "\n");
    }  
  }
  
  //Loop for payload system
  else {
    if(xBee_ser.available()>0){
      String command = xBee.readString();
      //check xBee for incoming messages that match ID
      if (command == "") return;        //Either no data was received or ID didn't match

      //Command responses
      if (command.equals("FLIP")) {   //toggle command
        if (isOn) ledOff();
        else ledOn();
      }
      else if ((command.substring(0,2)).equals("BL")) { //blink command
        byte times = (command.substring(2, command.length())).toInt();  //check to see how many times to blink
        ledBlink(times);
      }
      else if (command.equals("TIME"))  //report total time on command
        xBee.print("Time on (s): " + String(getTimeOn(), 3));
      else if (command.equals("NUM"))   //report times turned on command
        xBee.print("Turned on " + String(numberOn) + " times");
      else if (!command.equals(""))     //if a command was received, but not one of the above, display an error
        xBee.print("\nError - " + command + ": Command not recognized");
    }
  }
}

//turns led on and saves time and number
void ledOn() {
  if (!isOn) {
    digitalWrite(LED_PIN, HIGH);
    turnedOn = millis();
    isOn = true;
    numberOn++;
  }
}

//turns led off and adds time to total
void ledOff() {
  if (isOn) {
    digitalWrite(LED_PIN, LOW);
    timeOn += millis() - turnedOn;
    isOn = false;
  }
}

//blinks led a specified number of times
void ledBlink(byte times) {
  for (; times > 0; times--) {
    ledOn();
    delay(500);
    ledOff();
    delay(500);
  }
}

//returns time LED has been on, in seconds
float getTimeOn() {
  if (!isOn) return timeOn/1000.0;
  else return (timeOn + millis() - turnedOn)/1000.0;
}

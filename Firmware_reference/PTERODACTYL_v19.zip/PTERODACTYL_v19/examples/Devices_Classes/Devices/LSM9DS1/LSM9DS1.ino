#include <SparkFunLSM9DS1.h> // https://github.com/sparkfun/SparkFun_LSM9DS1_Arduino_Library

#define serialBAUD 115200           // when using arduino serial monitor, make sure baud rate is set to this same value

LSM9DS1 imu;

String header = "magnetometer x, magnetometer y, magnetometer z, accelerometer x, accelerometer y, accelerometer z, gyroscope x, gyroscope y, gyroscope z";

String data = "No Data";
String _print;

float gyroscope[3];
float accelerometer[3];
float magnetometer[3];

void setup() {
  // put your setup code here, to run once:
  Serial.begin(serialBAUD); //define baud rate in variable decleration above
  Serial.println("Serial online");
  
  _print = (imuSetup()) ? "IMU Online!\n" : "IMU Offline!\n";
  Serial.print(_print);
}

void loop() {
  // put your main code here, to run repeatedly:
  updateIMU();

  data = String(magnetometer[0]) + ", " + String(magnetometer[1]) + ", " + String(magnetometer[2]) + ", " +
         String(accelerometer[0]) + ", " + String(accelerometer[1]) + ", " + String(accelerometer[2]) + ", " +
         String(gyroscope[0]) + ", " + String(gyroscope[1]) + ", " + String(gyroscope[2]);

  Serial.println(header);
  Serial.println(data);
  Serial.println();
  
  delay(500);
}

bool imuSetup(){
  Wire.begin();
  if(!imu.begin()){
    return 0;
  }
  else{
    return 1;
  }
}

void updateIMU(){
  if( imu.gyroAvailable() ) imu.readGyro();
  if( imu.accelAvailable() ) imu.readAccel();
  if( imu.magAvailable() ) imu.readMag();

  magnetometer[0] = imu.calcMag(imu.mx);
  magnetometer[1] = imu.calcMag(imu.my);
  magnetometer[2] = imu.calcMag(imu.mz);
  accelerometer[0] = imu.calcAccel(imu.ax);
  accelerometer[1] = imu.calcAccel(imu.ay);
  accelerometer[2] = imu.calcAccel(imu.az);
  gyroscope[0] = imu.calcGyro(imu.gx);
  gyroscope[1] = imu.calcGyro(imu.gy);
  gyroscope[2] = imu.calcGyro(imu.gz);
}

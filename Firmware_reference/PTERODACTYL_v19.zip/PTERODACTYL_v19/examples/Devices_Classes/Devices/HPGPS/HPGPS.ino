#include <SparkFun_u-blox_GNSS_Arduino_Library.h> //http://librarymanager/All#SparkFun_u-blox_GNSS

bool usingM9N = true;                         //sparkfun library = NAV messages (ecef & PVT), tiny GPS = NMEA messages (traditional LLA)

int gpsBaud = 38400;     // 9600 for M8 & 38400 for M9 GPS
unsigned long gpsTimer = 0;
byte gpsStatus = 0;

bool hpGPS = false;
int gpsMonth = 999;
int gpsDay = 999;
int gpsYear = 999;
int gpsHour = 999;
int gpsMinute = 999;
int gpsSecond = 999;
double gpsLat = 999;
double gpsLon = 999;
double gpsAltM = 999;
double gpsAltFt = 999;
double gpsGndSpeed = 999;
double gpsHeading = 999;
double gpsPDOP = 999;

//High Percision GPS
float altitudeFtGPS = 999;
float latitudeGPS = 999;
float longitudeGPS = 999;
//initializaiton of ECEF variables
double ecefX = 999, ecefY = 999, ecefZ = 999;
double posAcc = 999;
byte SIV = 0;
//double latCalc = 999, longCalc = 999, altCalcFt = 999;
//UTM vairabels:
double UTMNorthing = 999, UTMEasting = 999;
char UTMZoneLetter = '?';
int UTMZoneNum = 999;

int setDynModel = 0;

bool ecefStatus = false;

String _print;

long timer;

void setup() {
  // put your setup code here, to run once:
  while(gpsStatus != 7){
        _print = (setupHPGPS() == 7) ? "HP GPS  Online!" : "HP GPS  Offline... Retrying";
        Serial.println(_print);
        delay(100);
    }

}

void loop() {
  // put your main code here, to run repeatedly:
  if (gpsStatus == 7) updateHPGPS();
  timer = millis();

  _print = String(timer) + ", " + String(SIV) + ", " + 
  String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + ", " +
  String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond) + ", " +
  String(gpsLat) + ", " +String(gpsLon) + ", " + String(gpsAltFt) + ", " + String(gpsAltM) + ", " + 
  
  String(ecefX) + ", " +String(ecefY) + ", " +String(ecefZ) + ", " + 
  //String(latCalc) + ", " +String(longCalc) + ", " +String(altCalcFt) + ", " + 
  String(UTMZoneNum) + String(UTMZoneLetter) + ", " + String(UTMEasting) + ", " + String(UTMNorthing) + ", " +
  String(gpsGndSpeed) + ", " + String(gpsHeading) + ", " + String(gpsPDOP);

  Serial.println(_print);
  delay(100);
}
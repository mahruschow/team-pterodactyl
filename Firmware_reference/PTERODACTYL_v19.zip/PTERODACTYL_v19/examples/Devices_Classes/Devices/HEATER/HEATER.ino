#include <PT_Thermistor.h>   // Custom Library to use Thermistors
#include <PT_OLED.h>         // Custom Library to use OLED

#define BUTTON_PIN 30         
#define SWITCH_PIN 31
// OLED
OLED OLED;   // Input the pins that the MS5611 is using

String _print;
double timer;
const unsigned int setupDelay = 499;
//////////////////////////////////////////////////////////////////////////
#define heaterSet 28
#define heaterReset 29

Thermistor ThermistorHeater(20);

//float heaterTempValue; // This will be set by some sensor read function. Just pretend this variable always has the temperature
float minimumTemperature = 80;
float maximumTemperature = 90; // all of these are redudant, but allows for changing of maximum/min temp as opposed to having max temp be just = to tolerance

//Heater
String heaterStatus = "N/A";
String header = "htrT(F),htrStat";

void setup(){
  Serial.begin(115200);
  OLED.begin();
  OLED.update("Init...");
  heaterSetup();
  Serial.println(header);
}

void loop(){
  updateHeater();
  _print = String(ThermistorHeater.getTempF()) + "," + heaterStatus;
  Serial.println(_print);
  OLED.update("\n" + heaterStatus + "\n\n" + String(ThermistorHeater.getTempF()));
  delay(500);
}

void heaterSetup(){
  pinMode(heaterSet,OUTPUT);
  pinMode(heaterReset,OUTPUT);

  while (ThermistorHeater.getStatus() == 0){
      if(millis()-timer > 250){
          _print = (ThermistorHeater.begin(12)) ? "Therm Htr Online!" : "Therm Htr Offline...Skip: B\nRetry: S";
          Serial.println(_print);  // Since this is a Teensy we are using, the read bit resolution can be at a max of 13 (12 for Teensy 4.1).
          OLED.update(_print);     // The maximum adc value given to the thermistor, should be 8191 (2^13) for a Teensy 3.6, 
          timer = millis();        // 4095 (2^12) for a Teensy 4.1, and 1023 (2^10) for an Arduino
      }
      if(ThermistorHeater.getStatus() == 0) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
  }
}

float updateHeater() {
  if (ThermistorHeater.getStatus()){
    ThermistorHeater.update();
    if(ThermistorHeater.getTempF() <= minimumTemperature){ 
      digitalWrite(heaterReset,HIGH);
      delay(10);
      digitalWrite(heaterReset,LOW);
      heaterStatus = "ON";
    }
    else if(ThermistorHeater.getTempF() >= maximumTemperature){ 
      digitalWrite(heaterSet,HIGH);
      delay(10); 
      digitalWrite(heaterSet,LOW);
      heaterStatus = "OFF";
    }
  }
  return ThermistorHeater.getTempF();
}
///////////////////////////////////////////////////////////
void wait(unsigned const int t){ //Soft pause placed in code
  while(millis() - timer <= t) {}
  timer = millis();
}

bool updateButtonStatus(){ 
  bool buttonStatus = false;
  buttonStatus = (digitalRead(BUTTON_PIN) == 0) ? true : false;
  return buttonStatus;
}

bool updateSwitchStatus(){
  bool switchStatus = false;
  switchStatus = (digitalRead(SWITCH_PIN) == 0) ? true : false;
  return switchStatus;
}

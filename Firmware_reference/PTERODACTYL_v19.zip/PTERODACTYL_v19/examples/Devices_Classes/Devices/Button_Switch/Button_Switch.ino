/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/

#include <PT_LED.h>          // Custom Library to use LED's

#define switchPin 30         // the number of the switch pin
#define buttonPin 31         // the number of the pushbutton pin

LED LED1(3); // input the pins the LED's are on
LED LED2(5);

bool buttonStatus;
bool switchStatus;

void setup() {
  LED1.begin();
  LED2.begin();
  
  pinMode(buttonPin, INPUT_PULLUP); // initialize the pushbutton pin as an input
  pinMode(switchPin, INPUT_PULLUP); // initialize the switch pin as an input
}

void loop() {
  // read the state of the pushbutton value:
  buttonStatus = (digitalRead(buttonPin)) ? false : true;
  switchStatus = (digitalRead(switchPin)) ? false : true;

  // check if the pushbutton is pressed. If it is, the buttonState is HIGH:
  if (buttonStatus)  LED1.on();
  else  LED1.off();

  // check if the switch is grounded. If it is, the led is HIGH:
  if (switchStatus)  LED2.on();
  else  LED2.off();
}

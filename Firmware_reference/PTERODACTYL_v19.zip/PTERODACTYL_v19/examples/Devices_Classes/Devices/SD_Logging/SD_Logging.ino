/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: Code for the SD card on a Teensy 4.1

#include <SD.h>

#define SERIAL_BAUD 115200
#define CHIP_SELECT BUILTIN_SDCARD //Should highlight if you have teensy 3.5/3.6/4.0/4.1 selected

File datalog; // Constructed object that handles SD input and output, can input/output i.e read/write for multiple files
char filename[] = "SDCARD00.csv"; //Make sure dataFileN matches first and second place of the zeros in terms of the arrays index
const byte dataFileN1 = 6; 
const byte dataFileN2 = 7; 
bool sdStatus = false; // Status of datalog.begin();   
bool sdActive = false; // Status of if there are available file names i.e the SD could be full from files 0-99 

String header = "Timer(S)";
String _print;
String data;

unsigned long timer; // millis()/1000
String flightTimer;  // stores timer turned into a flight timer format

void setup() {
  Serial.begin(SERIAL_BAUD);
  _print = (sdSetup(filename, dataFileN1, dataFileN2) && sdActive) ? "Card initialized.\nCreating File... Logging to: " + String(filename) : (sdActive) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  Serial.println(_print);
  Serial.println(header);
}

void loop() {
  timer = millis() / 1000;
  flightTimer = flightTimeStr(timer); // turn timer into a string formatted timer.
  data = flightTimer;
  logData(data, filename);
  Serial.println(data);
  delay(1000);
}

///////// Functions ////////////
// void sdSetup()
// logData(String Data)

bool sdSetup(char *dataFile, byte const &N1, byte const &N2){
  pinMode(CHIP_SELECT,OUTPUT);
  if(!SD.begin(CHIP_SELECT)) sdStatus = 0;
  else {
      sdStatus = 1;
      for (byte i = 0; i < 100; i++) {
          dataFile[N1] = '0' + i/10; 
          dataFile[N2] = '0' + i%10;
          if (!SD.exists(dataFile)) {
             datalog = SD.open(dataFile, FILE_WRITE);
              sdActive = true;
              break;
          }
          else sdActive = false;
      }
  } 
  return sdStatus;
}

void logData(String const &Data, char const *dataFile){
  datalog = SD.open(dataFile, FILE_WRITE);
  datalog.println(Data);
  datalog.close();
}

String flightTimeStr(unsigned long t) { // Turns a time in seconds to a usable string for print statements  
  String fTime = "";                    // Format: "00:00:00" -> h:m:s
  fTime += (String(t / 3600) + ":");
  t %= 3600;
  fTime += String(t / 600);
  t %= 600;
  fTime += (String(t / 60) + ":");
  t %= 60;
  fTime += (String(t / 10) + String(t % 10));
  return fTime;
}

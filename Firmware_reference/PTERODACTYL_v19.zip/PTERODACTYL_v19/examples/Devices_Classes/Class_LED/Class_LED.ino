/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This sketch is a LED Class that will allow any number of LEDs
//         to be controlled
// Mostly taken from: https://youtu.be/S_uaROFnWSg

/***********************************************************************************************************************************************
LED Class Definition
************************************************************************************************************************************************
class LED{
  public:
    LED(int pin);
    void begin();
    void on();
    void off();
    bool status();
  
  private:
    int _pin;
    bool _status;
    
};

************************************************************************************************************************************************
LED Member Defenition
************************************************************************************************************************************************
LED::LED(int pin){  // constructor
  _pin = pin; // here is where the pin you want to use is stored within the class DigitalLED
}

void LED::begin(){ // this initializes the pin
  pinMode(_pin, OUTPUT);
}

void LED::on(){ //this turns the pin on
  digitalWrite(_pin, HIGH);
  _status = 1;
}

void LED::off(){ // this turns the pin off
  digitalWrite(_pin, LOW);
  _status = 0;
}

bool LED::status(){ // this returns the 
  return _status;
}

************************************************************************************************************************************************
Arduino Sketch Start
************************************************************************************************************************************************/

#include <PT_LED.h>  // class is inside this library

LED LED1(2);
LED LED2(3);
LED LED3(4);
LED LED4(5);


void setup() {
  // put your setup code here, to run once:
  LED1.begin();
  LED2.begin();
  LED3.begin();
  LED4.begin();

}

void loop() {
  // put your main code here, to run repeatedly:
  
  LED1.on();
  delay(200);
  LED3.off();
  LED2.on();
  delay(200);
  LED1.off();
  LED4.on();
  delay(200);
  LED2.off();
  LED3.on();
  delay(200);
  LED4.off();
  
}

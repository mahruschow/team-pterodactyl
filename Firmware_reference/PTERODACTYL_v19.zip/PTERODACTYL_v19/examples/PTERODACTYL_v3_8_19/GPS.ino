/************************************************
      MnSGC Ballooning PTERODACTYL Flight Code
      Created by: Ashton Posey
                  Ethan Thompson-Jewell
      Modification Date: 1/14/24
************************************************/
//Purpose: This sketch is a combination of functions to communicate with the M9N & M8N GPS Over Serial & I2C

//#include <SparkFun_u-blox_GNSS_Arduino_Library.h> //http://librarymanager/All#SparkFun_u-blox_GNSS
#define GPS_FREQUENCY_I2C 25.0 // IF YOU ARE USING THE F9P ALONE (i.e. no d9s) 10Hz IS OPTIMAL 25Hz IS NOT POSSIBLE ON THE F9P
#define GPS_FREQUENCY_UART 8.0 // UART is slower, 25HZ currently not possible
#define GPS_FREQUENCY_SLOW 1.0

dynModel dynamicModel = DYN_MODEL_AIRBORNE2g; //setting dynamic model to 8 (airborne 4g) for rocket, 2g (for pterydactyl is 7)

/////////////////////////////////// RTK Correction Keys ///////////////////////////////////
// The D9S is a corrections reciever that uses the PointPerfect sattelite system to recieve corrections.
// If you are not using the D9S you are not using RTK and these keys are not required. 
// The f9P works just fine at 10Hz without the RTK
// Current Max Frequency of RTK is 1Hz
// Documentation for getting keys, can be found on the ballooning drive under F9P RTK GPS:
// https://docs.google.com/document/d/1LPn6epG78DDsRGPjsu2ZfjNjDn0iGQSRisbK2AWPjNg/edit?usp=sharing

// You can set the information below after signing up with the u-blox Thingstream portal 
// and adding a new New PointPerfect Thing (L-Band or L-Band + IP)
// https://portal.thingstream.io/app/location-services/things
// In the new PointPerfect Thing, you go to the credentials tab and copy and paste the IP Dynamic Keys here.
//
// The keys are valid from a particular GPS Week Number and Time of Week.
// Looking at the credentials tab, the current key expires 23:59 Feb 11th 2022.
// This means the next key is valid _from_ Midnight Feb 12th 2022.
// That is GPS Week 2196. The GPS Time of Week in seconds is 518400.
// Working backwards, the current key became valid exactly 4 weeks earlier (Midnight Jan 15th 2022).
//
// See: https://www.labsat.co.uk/index.php/en/gps-time-calculator
//
// The keys are given as: 32 hexadecimal digits = 128 bits = 16 Bytes
//
// The next example shows how to retrieve the keys using ESP32 WiFi and MQTT.
// You can cut and paste the keys and GPS week/time-of-week from that example into here.

const uint8_t currentKeyLengthBytes =   16; 
const char currentDynamicKey[] =        "7875bc2e9cb9252cef9070aef9ecd091";
const uint16_t currentKeyGPSWeek =      2297; // Update this when you add new keys
const uint32_t currentKeyGPSToW =       84558;

const uint8_t nextKeyLengthBytes =      16; 
const char nextDynamicKey[] =           "3fce6f457544996e2e6292b260b52cd7";
const uint16_t nextKeyGPSWeek =         2301; // Update this when you add new keys
const uint32_t nextKeyGPSToW =          84558;
/////////////////////////////////// RTK Correction Keys ///////////////////////////////////

int setupHPGPS(){
  LED2.on();
  OLED.update("\n\n   GPS\n  Setup");
  //sparkFunGNSS.enableDebugging(); // Uncomment this line to enable helpful debug messages on Serial

  if(gpsI2C){
      Wire1.begin();
      gpsStatus = false;
      unsigned int errorTimer = millis();
      while(!gpsStatus){
          gpsStatus = (sparkFunGNSS.begin(Wire1)) ? true : false;
          //Serial.print(gpsStatus);
          _print = (gpsStatus) ? "GPS       Online!" : "GPS       Offline...\n\nSkip: B\nRetry: S";
          Serial.println(_print);
          OLED.update(_print);
          if (gpsStatus) break;
          while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
          if (updateButtonStatus()) break;
          delay(100);
          if (millis() - errorTimer > errorDelay) {
              gpsStatus = 0;
              break;
          }
      }
      if (gpsStatus){
          // Disable or enable various NMEA sentences over the I2C interface
          sparkFunGNSS.setI2COutput(COM_TYPE_NMEA | COM_TYPE_UBX); // Turn on both UBX and NMEA sentences on I2C. (Turn off RTCM and SPARTN)
          //sparkFunGNSS.setI2COutput(COM_TYPE_UBX); // Turn on UBX sentences on I2C. (Turn off RTCM, SPARTN, & NMEA)
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GLL, COM_PORT_I2C); // Several of these are on by default on ublox board so let's disable them
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GSA, COM_PORT_I2C);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GSV, COM_PORT_I2C);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_RMC, COM_PORT_I2C);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_VTG, COM_PORT_I2C);
          sparkFunGNSS.enableNMEAMessage(UBX_NMEA_GGA, COM_PORT_I2C); // Leave only GGA enabled at current navigation rate
          // sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_I2C); // Produce 5 solutions per second [set number of times the callback function in called per second]
          // sparkFunGNSS.setMeasurementRate(dataDelay); //Produce a measurement every 1000ms
          //sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_I2C); // Produce 5 solutions per second [set number of times the callback function in called per second]
          sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_I2C); //Set output to 5 times a second
          byte rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
          Serial.println("Current Frequency: " + String(rate));
          if(rate != GPS_FREQUENCY_I2C){
              for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
                  sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_I2C); //Set output to 5 times a second
                  rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
                  Serial.println("Current Frequency: " + String(rate));
                  if(rate == GPS_FREQUENCY_I2C) break;
              }
          }
          //Serial.println("Current Frequency: " + String(rate));
          dataDelay = 1000 / GPS_FREQUENCY_I2C;
          Serial.println("Data Delay = " + String(dataDelay));
          int mesRate = sparkFunGNSS.setMeasurementRate(dataDelay);  //Produce a measurement every 1000ms
          Serial.println("Current Navigation Rate: " + String(rate));
          if (mesRate != dataDelay) {
            for (int i = 0; i < 50; i++) {                  //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
              sparkFunGNSS.setMeasurementRate(dataDelay);   //Set output to 5 times a second
              mesRate = sparkFunGNSS.getMeasurementRate();  //Get the update rate of this module
              Serial.println("Current Navigation Rate: " + String(mesRate));
              if (mesRate == dataDelay) break;
            }
          }

          //if (gpsI2C || gpsType == "M9")
          for (int i = 0; i < 10; i++) sparkFunGNSS.setAutoPVTrate(1);  //Tell the GNSS to send the PVT solution every measurement
          //sparkFunGNSS.setAutoPVTrate(1); //Tell the GNSS to send the PVT solution every measurement
          sparkFunGNSS.setAutoNAVPOSECEFrate(1); //Tell the GNSS to send each POSECEF solution every 5th measurement
          //sparkFunGNSS.setAutoNAVVELNEDrate(10); //Tell the GNSS to send each VELNED solution every 10th measurement
          sparkFunGNSS.saveConfiguration(); //Optional: Save the current settings to flash and BBR
      }
  }
  else  {
      gpsStatus = false;
      unsigned int errorTimer = millis();
      while(!gpsStatus){
          UBLOX_SERIAL.begin(gpsBaud);
          gpsStatus = (sparkFunGNSS.begin(UBLOX_SERIAL)) ? true : false;
          _print = (gpsStatus) ? "GPS       Online!" : "GPS       Offline...\n\nSkip: B\nRetry: S";
          Serial.println(_print);
          OLED.update(_print);
          if (gpsStatus) break;
          while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
          if (updateButtonStatus()) break;
          delay(100);
          if (millis() - errorTimer > errorDelay) {
              gpsStatus = 0;
              break;
          }
      }
      if (gpsStatus){
          sparkFunGNSS.setUART1Output(COM_TYPE_NMEA | COM_TYPE_UBX); //Turn off UBX and RTCM sentences on the UART1 interface
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GLL, COM_PORT_UART1); // Several of these are on by default on ublox board so let's disable them
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GSA, COM_PORT_UART1);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_GSV, COM_PORT_UART1);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_RMC, COM_PORT_UART1);
          sparkFunGNSS.disableNMEAMessage(UBX_NMEA_VTG, COM_PORT_UART1);
          sparkFunGNSS.enableNMEAMessage(UBX_NMEA_GGA, COM_PORT_UART1); // Leave only GGA enabled at current navigation rate
          // sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_UART); // [set number of times the callback function in called per second]
          if(gpsFast == true){
              sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_UART); //Set output to 5 times a second
              byte rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
              Serial.println("Current Frequency: " + String(rate));
              if(rate != GPS_FREQUENCY_UART){
                  for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
                      sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_UART); //Set output to 5 times a second
                      rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
                      Serial.println("Current Frequency: " + String(rate));
                      if(rate == GPS_FREQUENCY_UART) break;
                  }
              }
              //Serial.println("Current Frequency: " + String(rate));
              dataDelay = 1000 / GPS_FREQUENCY_UART;
              Serial.println("Data Delay = " + String(dataDelay));
              int mesRate = sparkFunGNSS.setMeasurementRate(dataDelay); //Produce a measurement every 1000ms
              Serial.println("Current Navigation Rate: " + String(rate));
              if(mesRate != dataDelay){
                  for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
                      sparkFunGNSS.setMeasurementRate(dataDelay); //Set output to 5 times a second
                      mesRate = sparkFunGNSS.getMeasurementRate(); //Get the update rate of this module
                      Serial.println("Current Navigation Rate: " + String(mesRate));
                      if(mesRate == dataDelay) break;
                  }
              }
        
              //if (gpsI2C || gpsType == "M9") 
              for (int i=0; i<10; i++) sparkFunGNSS.setAutoPVTrate(1); //Tell the GNSS to send the PVT solution every measurement
              //if (gpsType == "M9") sparkFunGNSS.setAutoNAVPOSECEFrate(1); //Tell the GNSS to send each POSECEF solution every 5th measurement
              //sparkFunGNSS.setAutoNAVVELNEDrate(10); //Tell the GNSS to send each VELNED solution every 10th measurement
              //sparkFunGNSS.saveConfiguration(); //Optional: Save the current settings to flash and BBR
          }
          delay(100);
      }
  }
  //Serial.println(gpsStatus);
  //Serial.println(gpsFast);
  if (gpsStatus){
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
      // Begin and configure the ZED-F9x
      if (rtkEnabled){
          //sparkFunGNSS.enableDebugging(); // Uncomment this line to enable helpful debug messages on Serial

          //uint8_t ok = sparkFunGNSS.setI2COutput(COM_TYPE_UBX); //Turn off NMEA noise
          
          //uint8_t ok = sparkFunGNSS.setPortInput(COM_PORT_I2C, COM_TYPE_UBX | COM_TYPE_NMEA | COM_TYPE_SPARTN); //Be sure SPARTN input is enabled
          //uint8_t ok = sparkFunGNSS.setPortInput(COM_PORT_UART1, COM_TYPE_UBX | COM_TYPE_NMEA | COM_TYPE_SPARTN); //Be sure SPARTN input is enabled
          uint8_t ok = sparkFunGNSS.setPortInput(COM_PORT_UART2, COM_TYPE_UBX | COM_TYPE_RTCM3 | COM_TYPE_SPARTN); //Be sure SPARTN input is enabled

          if (ok) ok = sparkFunGNSS.setDGNSSConfiguration(SFE_UBLOX_DGNSS_MODE_FIXED); // Set the differential mode - ambiguities are fixed whenever possible
          if (ok) ok = sparkFunGNSS.setVal8(UBLOX_CFG_SPARTN_USE_SOURCE, 1); // use LBAND PMP message

          //if (ok) ok = sparkFunGNSS.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_COR_I2C, 1); // Enable UBX-RXM-COR messages on I2C
          //if (ok) ok = sparkFunGNSS.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_COR_UART1, 1); // Enable UBX-RXM-COR messages on I2C
          if (ok) ok = sparkFunGNSS.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_COR_UART2, 1); // Enable UBX-RXM-COR messages on I2C
          
          //Configure the SPARTN IP Dynamic Keys
          //"When the receiver boots, the host should send 'current' and 'next' keys in one message." - Use setDynamicSPARTNKeys for this.
          //"Every time the 'current' key is expired, 'next' takes its place."
          //"Therefore the host should then retrieve the new 'next' key and send only that." - Use setDynamicSPARTNKey for this.
          // The key can be provided in binary (uint8_t) format or in ASCII Hex (char) format, but in both cases keyLengthBytes _must_ represent the binary key length in bytes.
          for (int i=0; i<5; i++) {
              if (ok) ok = sparkFunGNSS.setDynamicSPARTNKeys(currentKeyLengthBytes, currentKeyGPSWeek, currentKeyGPSToW, currentDynamicKey,
                                                            nextKeyLengthBytes, nextKeyGPSWeek, nextKeyGPSToW, nextDynamicKey);
              delay(50);
          }

          //if (ok) ok = sparkFunGNSS.saveConfiguration(VAL_CFG_SUBSEC_IOPORT | VAL_CFG_SUBSEC_MSGCONF); //Optional: Save the ioPort and message settings to NVM
          
          Serial.print(F("GNSS: configuration "));
          Serial.println(OK(ok));
          //sparkFunGNSS.setAutoPVTcallbackPtr(&printPVTdata); // Enable automatic NAV PVT messages with callback to printPVTdata so we can watch the carrier solution go to fixed

          //sparkFunGNSS.setRXMCORcallbackPtr(&printRXMCOR); // Print the contents of UBX-RXM-COR messages so we can check if the PMP data is being decrypted successfully

          //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
          // Begin and configure the NEO-D9S L-Band receiver

          //myLBand.enableDebugging(); // Uncomment this line to enable helpful debug messages on Serial
          //myLBand.enableDebugging(); // Uncomment this line to enable helpful debug messages on Serial
          for (int i=0; i<50 && !lbandStatus; i++){
              lbandStatus = (myLBand.begin(Wire1, 0x43)) ? true : false;

              if (!lbandStatus){
                  Serial.println("Trying L-Band Setup Again!");
                  OLED.update("Trying\nL-Band\nSetup\nAgain!");
              }

          }

          if (lbandStatus) {
              Serial.println("L-Band     Online!");
              OLED.update("\n\n  L-Band\n  Online!");
          }
          else {
              Serial.println("L-Band     Offline...");
              OLED.update("\n\n  L-Band\n  Offline");
          }

                  ok = myLBand.setVal32(UBLOX_CFG_PMP_CENTER_FREQUENCY,   myLBandFreq); // Default 1539812500 Hz
          if (ok) ok = myLBand.setVal16(UBLOX_CFG_PMP_SEARCH_WINDOW,      2200);        // Default 2200 Hz
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_PMP_USE_SERVICE_ID,      0);           // Default 1 
          if (ok) ok = myLBand.setVal16(UBLOX_CFG_PMP_SERVICE_ID,         21845);       // Default 50821
          if (ok) ok = myLBand.setVal16(UBLOX_CFG_PMP_DATA_RATE,          2400);        // Default 2400 bps
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_PMP_USE_DESCRAMBLER,     1);           // Default 1
          if (ok) ok = myLBand.setVal16(UBLOX_CFG_PMP_DESCRAMBLER_INIT,   26969);       // Default 23560
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_PMP_USE_PRESCRAMBLING,   0);           // Default 0
          if (ok) ok = myLBand.setVal64(UBLOX_CFG_PMP_UNIQUE_WORD,        16238547128276412563ull); 

          if (ok) ok = myLBand.setVal8(UBLOX_CFG_I2COUTPROT_UBX, 1);           // Enable UBX output on I2C
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_PMP_I2C,   1); // Ensure UBX-RXM-PMP is enabled on the I2C port 
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_UART1OUTPROT_UBX, 0);         // Enable UBX output on UART1
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_PMP_UART1, 0); // Output UBX-RXM-PMP on UART1
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_UART2OUTPROT_UBX, 1);         // Enable UBX output on UART2
          if (ok) ok = myLBand.setVal8(UBLOX_CFG_MSGOUT_UBX_RXM_PMP_UART2, 1); // Output UBX-RXM-PMP on UART2
          if (ok) ok = myLBand.setVal32(UBLOX_CFG_UART1_BAUDRATE,         38400); // match baudrate with ZED default
          if (ok) ok = myLBand.setVal32(UBLOX_CFG_UART2_BAUDRATE,         38400); // match baudrate with ZED default
          
          // Serial.print(F("L-Band: configuration "));
          // Serial.println(OK(ok));

          myLBand.softwareResetGNSSOnly(); // Do a restart

          timer = millis();

          // while (!rxmStatus){
          //     //sparkFunGNSS.setAutoPVTcallbackPtr(&printPVTdata); // Enable automatic NAV PVT messages with callback to printPVTdata so we can watch the carrier solution go to fixed
          //     sparkFunGNSS.setRXMCORcallbackPtr(&printRXMCOR); // Print the contents of UBX-RXM-COR messages so we can check if the PMP data is being decrypted successfully
          //     sparkFunGNSS.checkUblox(); // Check for the arrival of new GNSS data and process it.
          //     sparkFunGNSS.checkCallbacks(); // Check if any GNSS callbacks are waiting to be processed.
          //     Serial.println("F9P");
          // }
      }
      if(gpsFast){
          // Set the Main Talker ID to "GP". The NMEA GGA messages will be GPGGA instead of GNGGA
          //sparkFunGNSS.setMainTalkerID(SFE_UBLOX_MAIN_TALKER_ID_GP);
          //myGNSS.setMainTalkerID(SFE_UBLOX_MAIN_TALKER_ID_DEFAULT); // Uncomment this line to restore the default main talker ID

          //sparkFunGNSS.setHighPrecisionMode(true); // Enable High Precision Mode - include extra decimal places in the GGA messages
          // while (sparkFunGNSS.getNavigationFrequency() != 15) {
          //   Serial.println(sparkFunGNSS.getNavigationFrequency());
          //   sparkFunGNSS.setNavigationFrequency(15); // Produce 5 solutions per second [set number of times the callback function in called per second]
          //   delay(20);
          // }
          // sparkFunGNSS.setMeasurementRate(66); // setting the auto callback for the ECEF data
          // Serial.println(sparkFunGNSS.setHNRNavigationRate(66));
          // while (sparkFunGNSS.getHNRNavigationRate() != 66){ 
          //   delay(20);
          //   Serial.println(sparkFunGNSS.getHNRNavigationRate());
          //   sparkFunGNSS.setHNRNavigationRate(66);
          // }
          // while(!ecefStatus){ // Retry the callbackPtr function + updateECEF until ecefDataUpdate() is called correctly
          //     sparkFunGNSS.setAutoNAVPOSECEFcallbackPtr(&ecefDataUpdate); // Enable automatic NAV ECEF messages with callback to printECEFdata
          //     updateECEF();
          // }
      }
      else {
        // sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_SLOW); // Produce 1 solutions per second [set number of times the callback function in called per second]
        sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_SLOW); //Set output to 5 times a second
        byte rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
        Serial.println("Current Frequency: " + String(rate));
        if(rate != GPS_FREQUENCY_SLOW){
            for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
                sparkFunGNSS.setNavigationFrequency(GPS_FREQUENCY_SLOW); //Set output to 5 times a second
                rate = sparkFunGNSS.getNavigationFrequency(); //Get the update rate of this module
                Serial.println("Current Frequency: " + String(rate));
                if(rate == GPS_FREQUENCY_SLOW) break;
            }
        }
        //Serial.println("Current Frequency: " + String(rate));

        dataDelay = 1000 / GPS_FREQUENCY_SLOW;
        Serial.println("Data Delay = " + String(dataDelay));
        int mesRate = sparkFunGNSS.setMeasurementRate(dataDelay); //Produce a measurement every 1000ms
        Serial.println("Current Navigation Rate: " + String(rate));
        if(mesRate != dataDelay){
            for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
                sparkFunGNSS.setMeasurementRate(dataDelay); //Set output to 5 times a second
                mesRate = sparkFunGNSS.getMeasurementRate(); //Get the update rate of this module
                Serial.println("Current Navigation Rate: " + String(mesRate));
                if(mesRate == dataDelay) break;
            }
        }
        
        //if (gpsI2C || gpsType == "M9") 
        for (int i=0; i<10; i++) sparkFunGNSS.setAutoPVTrate(1); //Tell the GNSS to send the PVT solution every measurement
        
        if (gpsI2C) sparkFunGNSS.setAutoNAVPOSECEFrate(1); //Tell the GNSS to send each POSECEF solution every 5th measurement
        //sparkFunGNSS.saveConfiguration(); //Optional: Save the current settings to flash and BBR
        delay(100);
      }

      // Serial.println("Current Airmode: " + String(sparkFunGNSS.getDynamicModel()) + ", attempting to switch to airborne2g/7");
      for(int i=0; i<50; i++){ //reference list of dynamic models can be found at the bottom of this tab. 0 is pedestrian (default), 7 is airborne2g, 8 is airborne4g
          sparkFunGNSS.setDynamicModel(dynamicModel); //if returns 255 then that is an error, unable to communicate with gps
          gpsStatus  = (int)sparkFunGNSS.getDynamicModel();
          OLED.update("Airborne\nMode:\n" + String(gpsStatus) + "\n\nAttempt:\n" + String(i));
          Serial.println("Current Airmode: " + String(gpsStatus) + ", attempting to switch to airborne2g/7");
          if(gpsStatus == 7) break;

      }
  }
  LED2.off();
  Serial.println("GPS Status (7): " + String(gpsStatus));
  return gpsStatus;
}

void gpsUpdate(){
    pvtStatus = sparkFunGNSS.getPVT();
    if(pvtStatus){
    //if(true){
        gpsAltM =  sparkFunGNSS.getAltitude() * pow(10.0, -3); 
        gpsAltFt = gpsAltM * 3.280839895;
        gpsLat = sparkFunGNSS.getLatitude() * pow(10.0, -7);
        
        gpsLatDec = abs(long(gpsLat * pow(10.0, 7))) % 10000000;
        if (gpsLat < 0) gpsLatInt = floor(gpsLat) + 1;
        else gpsLatInt = floor(gpsLat);
        // Serial.println();
        // Serial.println(String(gpsLat));
        gpsLon = sparkFunGNSS.getLongitude() * pow(10.0, -7);

        gpsLonDec = abs(long(gpsLon * pow(10.0, 7))) % 10000000;
        if (gpsLon < 0) gpsLonInt = floor(gpsLon) + 1;
        else gpsLonInt = floor(gpsLon);

        SIV = sparkFunGNSS.getSIV();
        
        gpsMonth = sparkFunGNSS.getMonth();
        gpsDay = sparkFunGNSS.getDay();
        gpsYear = sparkFunGNSS.getYear();
        gpsHour = sparkFunGNSS.getHour() - 5;  // Their time zone is 5h ahead
        if (gpsHour < 0) gpsHour = gpsHour + 24;
        gpsMinute = sparkFunGNSS.getMinute();
        gpsSecond = sparkFunGNSS.getSecond();
        gpsMillisecond = sparkFunGNSS.getMillisecond();

        gpsTimeOfWeek = sparkFunGNSS.getTimeOfWeek();

        gpsGndSpeed = sparkFunGNSS.getGroundSpeed() * pow(10.0, -3); // mm to m
        gpsHeading = sparkFunGNSS.getHeading() * pow(10.0, -5); // deg * 10^5 to deg
        gpsPDOP = sparkFunGNSS.getPDOP();

        byte fixType = sparkFunGNSS.getFixType();
        if(fixType == 0) fixTypeGPS = "No fix";
        else if(fixType == 1) fixTypeGPS = "Dead reckoning";
        else if(fixType == 2) fixTypeGPS = "2D";
        else if(fixType == 3) fixTypeGPS =  "3D";
        else if(fixType == 4) fixTypeGPS = "GNSS + Dead reckoning";
        else if(fixType == 5) fixTypeGPS = "Time only";

        byte RTK = sparkFunGNSS.getCarrierSolutionType();
        if (RTK == 0) fixTypeRTK = "No RTK";
        else if (RTK == 1) fixTypeRTK = "HPF RTK";// Floating RTK Solution
        else if (RTK == 2) fixTypeRTK = "HP RTK"; // RTK Solution

        velocityNED[0] = sparkFunGNSS.getNedNorthVel() / 1000.0;
        velocityNED[1] = sparkFunGNSS.getNedEastVel() / 1000.0;
        velocityNED[2] = sparkFunGNSS.getNedDownVel() / 1000.0;

        gpsHorizAcc = sparkFunGNSS.getHorizontalAccEst(); // Print the horizontal accuracy estimate
        gpsVertAcc = sparkFunGNSS.getVerticalAccEst();

        updateUTM();
        sparkFunGNSS.flushPVT();

        gpsVertVelFt = (gpsAltFt - gpsPrevAlt) / (timerSec - gpsPrevTime);
        gpsVertVelM = gpsVertVelFt * 0.3047999995367;
        gpsPrevAlt = gpsAltFt;
        gpsPrevTime = timerSec;
    }
    //ecefStatus = false;
    ecefStatus = sparkFunGNSS.getNAVPOSECEF();
    if (ecefStatus){
    //if (true){
        ecefX = sparkFunGNSS.packetUBXNAVPOSECEF->data.ecefX; // convert ecefX to cm
        ecefY = sparkFunGNSS.packetUBXNAVPOSECEF->data.ecefY; // convert ecefY to cm
        ecefZ = sparkFunGNSS.packetUBXNAVPOSECEF->data.ecefZ; // convert ecefY to cm
        sparkFunGNSS.flushNAVPOSECEF(); //Mark all the data as read/stale so we get fresh data next time
    }
}

// //checks for new data, updates GPS and then if new ECEF data is available then funs 'ecefDataUpdate()'
// void updateECEF() {
//   sparkFunGNSS.checkUblox(); // Check for the arrival of new data and process it.
//   sparkFunGNSS.checkCallbacks(); // Check if any callbacks are waiting to be processed. (callback function is update ECEF)
// }

// void ecefDataUpdate(UBX_NAV_POSECEF_data_t *ubxDataStruct){ //funciton gets called any time there is updated ecef data if properly passed to the callbackPtr
//   if (!ecefStatus) ecefStatus = true;
//   //Serial.println("ecefeDateUpdate Has been called");
//   ecefX = ubxDataStruct->ecefX; // Print the X Value (output is usually in cm but converting to meters fro calcultions)
//   //ecefX /= 100;
//   ecefY = ubxDataStruct->ecefY; // Print the Y value
//   //ecefY /= 100;
//   ecefZ = ubxDataStruct->ecefZ; // Print the Z value
//   //ecefZ /= 100;
//   // posAcc = ubxDataStruct->pAcc; // Print the height above mean sea level
//   // posAcc /= 100;
//   //SIV = sparkFunGNSS.getSIV();
//   //calculate
//   //ecefToLLA(ecefX, ecefY, ecefZ, latCalc, longCalc, altCalcFt);
//   return;
// }

void updateHPLLA(){
    // getHighResLatitude: returns the latitude from HPPOSLLH as an int32_t in degrees * 10^-7
    // getHighResLatitudeHp: returns the high resolution component of latitude from HPPOSLLH as an int8_t in degrees * 10^-9
    // getHighResLongitude: returns the longitude from HPPOSLLH as an int32_t in degrees * 10^-7
    // getHighResLongitudeHp: returns the high resolution component of longitude from HPPOSLLH as an int8_t in degrees * 10^-9
    // getElipsoid: returns the height above ellipsoid as an int32_t in mm
    // getElipsoidHp: returns the high resolution component of the height above ellipsoid as an int8_t in mm * 10^-1
    // getMeanSeaLevel: returns the height above mean sea level as an int32_t in mm
    // getMeanSeaLevelHp: returns the high resolution component of the height above mean sea level as an int8_t in mm * 10^-1
    // getHorizontalAccuracy: returns the horizontal accuracy estimate from HPPOSLLH as an uint32_t in mm * 10^-1

    // If you want to use the high precision latitude and longitude with the full 9 decimal places
    // you will need to use a 64-bit double - which is not supported on all platforms

    // To allow this example to run on standard platforms, we cheat by converting lat and lon to integer and fractional degrees

    // The high resolution altitudes can be converted into standard 32-bit float

    // First, let's collect the position data
    //  gpsLat = sparkFunGNSS.getHighResLatitude();
    //  double gpsLatHp = sparkFunGNSS.getHighResLatitudeHp();

    //  Serial.println();
    //  Serial.println(String(gpsLat) + String(gpsLatHp));
    //  longitude = sparkFunGNSS.getHighResLongitude();
    //  longitudeHp = sparkFunGNSS.getHighResLongitudeHp();
    //  ellipsoid = sparkFunGNSS.getElipsoid();
    //  ellipsoidHp = sparkFunGNSS.getElipsoidHp();
    //  msl = sparkFunGNSS.getMeanSeaLevel();
    //  mslHp = sparkFunGNSS.getMeanSeaLevelHp();
    // uint32_t accuracy = sparkFunGNSS.getHorizontalAccuracy();

    // // Calculate the latitude and longitude integer and fractional parts
    // lat_int = latitude / 10000000; // Convert latitude from degrees * 10^-7 to Degrees
    // lat_frac = latitude - (lat_int * 10000000); // Calculate the fractional part of the latitude
    // lat_frac = (lat_frac * 100) + latitudeHp; // Now add the high resolution component
    // if (lat_frac < 0) // If the fractional part is negative, remove the minus sign
    // {
    //   lat_frac = 0 - lat_frac;
    // }
    // lon_int = longitude / 10000000; // Convert latitude from degrees * 10^-7 to Degrees
    // lon_frac = longitude - (lon_int * 10000000); // Calculate the fractional part of the longitude
    // lon_frac = (lon_frac * 100) + longitudeHp; // Now add the high resolution component
    // if (lon_frac < 0) // If the fractional part is negative, remove the minus sign
    // {
    //   lon_frac = 0 - lon_frac;
    // }

    // // Calculate the height above ellipsoid in mm * 10^-1
    // f_ellipsoid = (ellipsoid * 10) + ellipsoidHp;
    // // Now convert to m
    // f_ellipsoid = f_ellipsoid / 10000.0; // Convert from mm * 10^-1 to m

    // // Calculate the height above mean sea level in mm * 10^-1
    // f_msl = (msl * 10) + mslHp;
    // // Now convert to m
    // f_msl = f_msl / 10000.0; // Convert from mm * 10^-1 to m

    // // Convert the horizontal accuracy (mm * 10^-1) to a float
    // //f_accuracy = accuracy;
    // // Now convert to m
    // f_accuracy = f_accuracy / 10000.0; // Convert from mm * 10^-1 to m
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

// Callback: printRXMCOR will be called when new RXM COR data arrives
// See u-blox_structs.h for the full definition of UBX_RXM_COR_data_t
//         _____  You can use any name you like for the callback. Use the same name when you call setRXMCORcallbackPtr
//        /                  _____  This _must_ be UBX_RXM_COR_data_t
//        |                 /               _____ You can use any name you like for the struct
//        |                 |              /
//        |                 |              |
void printRXMCOR(UBX_RXM_COR_data_t *ubxDataStruct)
{
  rxmStatus = true;
  Serial.print(F("UBX-RXM-COR:  ebno: "));
  Serial.print((double)ubxDataStruct->ebno / 8, 3); //Convert to dB

  Serial.print(F("  protocol: "));
  if (ubxDataStruct->statusInfo.bits.protocol == 1)
    Serial.print(F("RTCM3"));
  else if (ubxDataStruct->statusInfo.bits.protocol == 2)
    Serial.print(F("SPARTN"));
  else if (ubxDataStruct->statusInfo.bits.protocol == 29)
    Serial.print(F("PMP (SPARTN)"));
  else if (ubxDataStruct->statusInfo.bits.protocol == 30)
    Serial.print(F("QZSSL6"));
  else
    Serial.print(F("Unknown"));

  Serial.print(F("  errStatus: "));
  if (ubxDataStruct->statusInfo.bits.errStatus == 1)
    Serial.print(F("Error-free"));
  else if (ubxDataStruct->statusInfo.bits.errStatus == 2)
    Serial.print(F("Erroneous"));
  else
    Serial.print(F("Unknown"));

  Serial.print(F("  msgUsed: "));
  if (ubxDataStruct->statusInfo.bits.msgUsed == 1)
    Serial.print(F("Not used"));
  else if (ubxDataStruct->statusInfo.bits.msgUsed == 2)
    Serial.print(F("Used"));
  else
    Serial.print(F("Unknown"));

  Serial.print(F("  msgEncrypted: "));
  if (ubxDataStruct->statusInfo.bits.msgEncrypted == 1)
    Serial.print(F("Not encrypted"));
  else if (ubxDataStruct->statusInfo.bits.msgEncrypted == 2)
    Serial.print(F("Encrypted"));
  else
    Serial.print(F("Unknown"));

  Serial.print(F("  msgDecrypted: "));
  if (ubxDataStruct->statusInfo.bits.msgDecrypted == 1)
    Serial.print(F("Not decrypted"));
  else if (ubxDataStruct->statusInfo.bits.msgDecrypted == 2)
    Serial.print(F("Successfully decrypted"));
  else
    Serial.print(F("Unknown"));

  Serial.println();
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

//funciton to update the UTM & LLA coordinates.
void updateUTM() {//call function to find the UTM variables. the lat and long variabels that are being passed in are taken directally from the PVT values
  LLtoUTM(gpsLat, gpsLon, UTMNorthing, UTMEasting, UTMZoneNum); //conversion is using direct LLA values
  UTMZoneLetter = UTMLetterDesignator(gpsLat); //passes in current latitude in order to find the letter designation for northing and easting
}

//%%%%%%%%%%%%%%%%%%% BELOW ARE FUNCTIONS TO CONVERT FROM LLA TO UTM COORDINATES %%%%%%%%%%%%%%%%%%%
//this is a function that will convert a given LLA Value to UTM (Easting and Northing) coordinates.
// taken from:  https://github.com/bakercp/ofxGeo/blob/master/libs/UTM/include/UTM/UTM.h
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
// Grid granularity for rounding UTM coordinates to generate MapXY.
const double grid_size = 100000.0;    ///< 100 km grid

// WGS84 Parameters
#define WGS84_A    6378137.0   ///< major axis
#define WGS84_B   6356752.31424518  ///< minor axis
#define WGS84_F   0.0033528107    ///< ellipsoid flattening
#define WGS84_E   0.0818191908    ///< first eccentricity
#define WGS84_EP  0.0820944379    ///< second eccentricity

// UTM Parameters
#define UTM_K0    0.9996      ///< scale factor
#define UTM_FE    500000.0    ///< false easting
#define UTM_FN_N  0.0           ///< false northing, northern hemisphere
#define UTM_FN_S  10000000.0    ///< false northing, southern hemisphere
#define UTM_E2    (WGS84_E*WGS84_E) ///< e^2
#define UTM_E4    (UTM_E2*UTM_E2)   ///< e^4
#define UTM_E6    (UTM_E4*UTM_E2)   ///< e^6
#define UTM_EP2   (UTM_E2/(1-UTM_E2)) ///< e'^2

/**
   Determine the correct UTM letter designator for the
   given latitude

   @returns 'Z' if latitude is outside the UTM limits of 84N to 80S

   Written by Chuck Gantz- chuck.gantz@globalstar.com
*/
static inline char UTMLetterDesignator(double Lat)
{
  char LetterDesignator;

  if     ((84 >= Lat) && (Lat >= 72))  LetterDesignator = 'X';
  else if ((72 > Lat) && (Lat >= 64))  LetterDesignator = 'W';
  else if ((64 > Lat) && (Lat >= 56))  LetterDesignator = 'V';
  else if ((56 > Lat) && (Lat >= 48))  LetterDesignator = 'U';
  else if ((48 > Lat) && (Lat >= 40))  LetterDesignator = 'T';
  else if ((40 > Lat) && (Lat >= 32))  LetterDesignator = 'S';
  else if ((32 > Lat) && (Lat >= 24))  LetterDesignator = 'R';
  else if ((24 > Lat) && (Lat >= 16))  LetterDesignator = 'Q';
  else if ((16 > Lat) && (Lat >= 8))   LetterDesignator = 'P';
  else if (( 8 > Lat) && (Lat >= 0))   LetterDesignator = 'N';
  else if (( 0 > Lat) && (Lat >= -8))  LetterDesignator = 'M';
  else if ((-8 > Lat) && (Lat >= -16)) LetterDesignator = 'L';
  else if ((-16 > Lat) && (Lat >= -24)) LetterDesignator = 'K';
  else if ((-24 > Lat) && (Lat >= -32)) LetterDesignator = 'J';
  else if ((-32 > Lat) && (Lat >= -40)) LetterDesignator = 'H';
  else if ((-40 > Lat) && (Lat >= -48)) LetterDesignator = 'G';
  else if ((-48 > Lat) && (Lat >= -56)) LetterDesignator = 'F';
  else if ((-56 > Lat) && (Lat >= -64)) LetterDesignator = 'E';
  else if ((-64 > Lat) && (Lat >= -72)) LetterDesignator = 'D';
  else if ((-72 > Lat) && (Lat >= -80)) LetterDesignator = 'C';
  // 'Z' is an error flag, the Latitude is outside the UTM limits
  else LetterDesignator = 'Z';
  return LetterDesignator;
}

/**
   Convert lat/long to UTM coords.  Equations from USGS Bulletin 1532

   East Longitudes are positive, West longitudes are negative.
   North latitudes are positive, South latitudes are negative
   Lat and Long are in fractional degrees

   Written by Chuck Gantz- chuck.gantz@globalstar.com
*/
static inline void LLtoUTM(const double Lat, const double Long,
                           double &UTMNorthing, double &UTMEasting,
                           int &UTMZone) //this has been edited so it includes UTM as an int not a char
{
  double a = WGS84_A;
  double eccSquared = UTM_E2;
  double k0 = UTM_K0;

  double LongOrigin;
  double eccPrimeSquared;
  double N, T, C, A, M;

  //Make sure the longitude is between -180.00 .. 179.9
  double LongTemp = (Long + 180) - int((Long + 180) / 360) * 360 - 180;
  // Serial.println("HERE IS LONG TEMP: " + String(LongTemp));

  double LatRad = Lat * DEG_TO_RAD;
  double LongRad = LongTemp * DEG_TO_RAD;
  double LongOriginRad;
  int    ZoneNumber;

  ZoneNumber = int((LongTemp + 180) / 6) + 1;

  if ( Lat >= 56.0 && Lat < 64.0 && LongTemp >= 3.0 && LongTemp < 12.0 )
    ZoneNumber = 32;

  // Special zones for Svalbard
  if ( Lat >= 72.0 && Lat < 84.0 )
  {
    if (      LongTemp >= 0.0  && LongTemp <  9.0 ) ZoneNumber = 31;
    else if ( LongTemp >= 9.0  && LongTemp < 21.0 ) ZoneNumber = 33;
    else if ( LongTemp >= 21.0 && LongTemp < 33.0 ) ZoneNumber = 35;
    else if ( LongTemp >= 33.0 && LongTemp < 42.0 ) ZoneNumber = 37;
  }
  // +3 puts origin in middle of zone
  LongOrigin = (ZoneNumber - 1) * 6 - 180 + 3;
  LongOriginRad = LongOrigin * DEG_TO_RAD;

  //compute the UTM Zone from the latitude and longitude
  // sprintf(UTMZone, "%d%c", ZoneNumber, UTMLetterDesignator(Lat)); //commented out bc doesnt work

  UTMZone = ZoneNumber;    //save the found zone number to UTMZone

  eccPrimeSquared = (eccSquared) / (1 - eccSquared);

  N = a / sqrt(1 - eccSquared * sin(LatRad) * sin(LatRad));
  T = tan(LatRad) * tan(LatRad);
  C = eccPrimeSquared * cos(LatRad) * cos(LatRad);
  A = cos(LatRad) * (LongRad - LongOriginRad);

  M = a * ((1 - eccSquared / 4 - 3 * eccSquared * eccSquared / 64
          - 5 * eccSquared * eccSquared * eccSquared / 256) * LatRad
          - (3 * eccSquared / 8 + 3 * eccSquared * eccSquared / 32
          + 45 * eccSquared * eccSquared * eccSquared / 1024) * sin(2 * LatRad)
          + (15 * eccSquared * eccSquared / 256
          + 45 * eccSquared * eccSquared * eccSquared / 1024) * sin(4 * LatRad)
          - (35 * eccSquared * eccSquared * eccSquared / 3072) * sin(6 * LatRad));

  UTMEasting = (double)
              (k0 * N * (A + (1 - T + C) * A * A * A / 6
              + (5 - 18 * T + T * T + 72 * C - 58 * eccPrimeSquared) * A * A * A * A * A / 120)
              + 500000.0);

  UTMNorthing = (double)
              (k0 * (M + N * tan(LatRad)
              * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A * A * A * A / 24
              + (61 - 58 * T + T * T + 600 * C - 330 * eccPrimeSquared) * A * A * A * A * A * A / 720)));

  if (Lat < 0)
  {
    //10000000 meter offset for southern hemisphere
    UTMNorthing += 10000000.0;
  }
}

/**
   Converts UTM coords to lat/long.  Equations from USGS Bulletin 1532

   East Longitudes are positive, West longitudes are negative.
   North latitudes are positive, South latitudes are negative
   Lat and Long are in fractional degrees.

   Written by Chuck Gantz- chuck.gantz@globalstar.com
*/
static inline void UTMtoLL(const double UTMNorthing, const double UTMEasting, const char* UTMZone, double& Lat, double& Long){
  double k0 = UTM_K0;
  double a = WGS84_A;
  double eccSquared = UTM_E2;
  double eccPrimeSquared;
  double e1 = (1 - sqrt(1 - eccSquared)) / (1 + sqrt(1 - eccSquared));
  double N1, T1, C1, R1, D, M;
  double LongOrigin;
  double mu, phi1Rad;
  double x, y;
  int ZoneNumber;
  char* ZoneLetter;

  x = UTMEasting - 500000.0; //remove 500,000 meter offset for longitude
  y = UTMNorthing;

  ZoneNumber = strtoul(UTMZone, &ZoneLetter, 10);
  if ((*ZoneLetter - 'N') < 0){//remove 10,000,000 meter offset used for southern hemisphere
      y -= 10000000.0;
  }

  //+3 puts origin in middle of zone
  LongOrigin = (ZoneNumber - 1) * 6 - 180 + 3;
  eccPrimeSquared = (eccSquared) / (1 - eccSquared);

  M = y / k0;
  mu = M / (a * (1 - eccSquared / 4 - 3 * eccSquared * eccSquared / 64
                 - 5 * eccSquared * eccSquared * eccSquared / 256));

  phi1Rad = mu + ((3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * sin(2 * mu)
                  + (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * sin(4 * mu)
                  + (151 * e1 * e1 * e1 / 96) * sin(6 * mu));

  N1 = a / sqrt(1 - eccSquared * sin(phi1Rad) * sin(phi1Rad));
  T1 = tan(phi1Rad) * tan(phi1Rad);
  C1 = eccPrimeSquared * cos(phi1Rad) * cos(phi1Rad);
  R1 = a * (1 - eccSquared) / pow(1 - eccSquared * sin(phi1Rad) * sin(phi1Rad), 1.5);
  D = x / (N1 * k0);

  Lat = phi1Rad - ((N1 * tan(phi1Rad) / R1)
                  * (D * D / 2
                  - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * eccPrimeSquared) * D * D * D * D / 24
                  + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * eccPrimeSquared
                  - 3 * C1 * C1) * D * D * D * D * D * D / 720));

  Lat = Lat * RAD_TO_DEG;

  Long = ((D - (1 + 2 * T1 + C1) * D * D * D / 6
           + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * eccPrimeSquared + 24 * T1 * T1)
           * D * D * D * D * D / 120)
           / cos(phi1Rad));
  Long = LongOrigin + Long * RAD_TO_DEG;

}
//%%%%%%%%%%%%%%%%%%% ABOVE ARE FUNCTIONS TO CONVERT FROM LLA TO UTM COORDINATES %%%%%%%%%%%%%%%%%%%




//%%%%%%%%%%%%%%%%%%%%%%%  BELOW  are functions to convert ECEF to LLA format %%%%%%%%%%%%%%%%%%%%%%%

// #define pi 3.1415926535897
// #define rad2Deg 180.00/pi

// const double a = 6378137.00;
// const double b = 6356752.31424518;
// const double f = 1 / (298.257223563);
// const double e = sqrt( (pow(a, 2) - pow(b, 2)) / pow(a, 2) );
// const double ePrime = sqrt( (pow(a, 2) - pow(b, 2)) / pow(b, 2) );


//below function takes what ever ecef values are stored at time of calling and uses them to convert into LLA format
// x, y, and z are their respective ecef coordinates, and the lat, long, and alt (ft) should be the variables the calculations are saved to
// void ecefToLLA(double x, double y, double  z, double  &latitude, double  &longitude, double  &alt)
// {
//   //finding auxillary values to simplify formulas:
//   double p = sqrt(pow(x, 2) + pow(y, 2));
//   double theta = atan((z * a) / (p * b));

//   //converting into long
//   longitude = atan(y / x) - pi;
//   longitude = longitude * 180.0 / pi;

//   //converting into latitude
//   double latNumerator = z + pow(ePrime, 2) * b * pow(sin(theta), 3);
//   double latDenominator = p - pow(e, 2) * a * pow(cos(theta), 3);
//   latitude = atan(latNumerator / latDenominator) * (180.0 / pi);


//   //finding radius of cervature 'N' in order to calculator altitude:
//   double n = a / (sqrt( 1 - ( pow(e, 2) * pow(sin(latitude * pi / 180.0) , 2))));
//   //final calculation for the altitude
//   alt = ((p / cos(latitude * pi / 180.0)) - n)  * 3.280839895;

//   return;
// }
//%%%%%%%%%%%%%%%%%%%%%%% ABOVE  are functions to convert ECEF to LLA format %%%%%%%%%%%%%%%%%%%%%%%

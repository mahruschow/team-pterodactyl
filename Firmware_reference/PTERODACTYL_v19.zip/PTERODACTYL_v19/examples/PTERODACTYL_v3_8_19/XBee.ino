/************************************************
      MnSGC Ballooning PTERODACTYL Flight Code
      Created by: Ashton Posey
                  Ryan Bowers
      Modification Date: 1/14/24
************************************************/
//Purpose: This sketch is a combination of functions to communicate with the XBee over serial

String scanChID = "CCCC";
String xbeeSerialData;

const int serialTimeout = 10; // millis after string is recieved that the .read() will time-out -> Including .readString() & .readStringUntil(char) 

//const int stringLen = 80;

////////////////////////////////////////////// Functions ///////////////////////////////////////////////
// bool xbeeSetup();
// void listenXBee();
// void updateXBee();
// String buildString();

bool xBeeSetup() {
  XBeeSerial.begin(XBEE_BAUD);
  
  if(configStatus){
    delay(300);
    counterID = 10;
    currentSwitchStatus = updateSwitchStatus();           // If switch is moved add one to the XBee Channel. 10-19
    while (updateButtonStatus() == 0){
        unsigned int errorTimer = millis();                
        if (updateSwitchStatus() != currentSwitchStatus) {
          counterID++;
          if (counterID == 20) counterID = 10;
          channelID = String(counterID);
        }
        OLED.update("XBee\nChannel:\n" + String(channelID) + "\nMove S\nto add 1\nPress: B");
        Serial.println("XBee Channel: " + String(channelID) + ". Move Switch to add 1. Press Button to continue.");
        currentSwitchStatus = updateSwitchStatus();
        while (currentSwitchStatus == updateSwitchStatus() && updateButtonStatus() == 0){
           delay(20); // wait for a change in switch status or a button press
           if (millis() - errorTimer > errorDelay) break;
        }
        if (millis() - errorTimer > errorDelay) break;
    }
    counterID = 0;
    logData(channelID, config);  // Log data to SD
    delay(300);

    counterID = 100;
    currentSwitchStatus = updateSwitchStatus();                     // If switch is moved add one to the XBee Network. A100-A200
    while (updateButtonStatus() == 0){
        unsigned int errorTimer = millis(); 
        if (updateSwitchStatus() != currentSwitchStatus) {
          counterID++;
          if (counterID == 200) counterID = 100;
          networkID = "A" + String(counterID);
        }
        OLED.update("XBee\nNetwork:\n" + String(networkID) + "\nMove S\nto add 1\nPress: B");
        Serial.println("XBee Network: " + String(networkID) + ". Move Switch to add 1. Press Button to continue.");
        currentSwitchStatus = updateSwitchStatus();
        while (currentSwitchStatus == updateSwitchStatus() && updateButtonStatus() == 0){
           delay(20); // wait for a change in switch status or a button press
           if (millis() - errorTimer > errorDelay) break;
        }
        if (millis() - errorTimer > errorDelay) break;
    }
    logData(networkID, config);  // Log data to SD
    counterID = 0;
    delay(300);

    xbeeTimerSec = millis();
    OLED.update("XBee Mode\nRly: S On\nRec:S Off\n\n\nPress B");
    Serial.println("XBee Mode\nRelay: Switch On\nReciever: Switch off\nPress Button to Continue");
    unsigned int errorTimer = millis();
    while(!updateButtonStatus()) { 
        if(updateSwitchStatus()){
            LED3.on();
            LED5.off();
            isRelay = true;
            OLED.update("XBee Mode\nRly: S On+Rec:S Off\n\n\nPress B");
        }
        if(!updateSwitchStatus()){
            LED5.on();
            LED3.off();
            isRelay = false;
            OLED.update("XBee Mode\nRly: S On\nRec:S Off+\n\nPress B");
        }
        if (millis() - errorTimer > errorDelay) break;
        delay(20);
    }
    LED3.off();
    LED5.off();
    logData(String(isRelay), config);  // Log data to SD
  }

  if (isRelay) {     //turn on the switch on startup to put the Arduino in Relay Mode
    LED3.on();
    isRelay = true;
    xbee.enterATmode();
    xbee.atCommand("ATRE");
    xbee.atCommand("ATCH" + channelID);
    xbee.atCommand("ATID" + networkID);
    xbee.atCommand("ATSC" + scanChID);
    xbee.atCommand("ATDL1");             //Configure XBee as a relay
    xbee.atCommand("ATMY0");
    //xbee.atCommand("ATD61");
    xbee.exitATmode();
    if(configStatus){
      unsigned int errorTimer = millis(); 
      currentSwitchStatus = updateSwitchStatus(); 
      while (updateButtonStatus() == 0){ 
          if (updateSwitchStatus() != currentSwitchStatus) counterID++; // If switch is moved add one to the amount of xbees in the network
          OLED.update("# XBee " + String(counterID) + "\nMove S\nto add 1\n\n\nPress: B");
          Serial.println("# of XBees " + String(counterID) + ". Move S to add 1. Press B to continue.");
          currentSwitchStatus = updateSwitchStatus();
          while (currentSwitchStatus == updateSwitchStatus() && updateButtonStatus() == 0){
           delay(20); // wait for a change in switch status or a button press
           if (millis() - errorTimer > errorDelay) break;
          }
          if (millis() - errorTimer > errorDelay) break;
      }
      logData(String(counterID), config);  // Log data to SD
    }
    //numberOfXbees = counterID;
    xbeeRate = counterID;
    for (int i=0; i<counterID; i++){  // create a filename for all xbee recievers that will be in the network
        xbeeFilename[xbeeFileC] = char(i+65); // change the filename spot to corresponding char for each xbee, A is xbee 1, B is xbee 2, etc.
        _print = (sdSetup(xbeeFilename, xbeeFileN1, xbeeFileN2) && sdActive) ? "SD Card   Online... Creating File... Logging to: " + String(xbeeFilename) : (sdActive) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
        Serial.println(_print);
        //Serial.println(xbeeFilename);     
        _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(xbeeFilename) + "\n\n" + String(xbeeFilename[xbeeFileC]) : (sdActive) ? "NAFM\nClear SD" : "SD\nFailed";
        OLED.update(_print);
        logData(header, xbeeFilename);
        xbeeFilenames[i][0] = xbeeFilename[xbeeFileC]; 
        xbeeFilenames[i][1] = xbeeFilename[xbeeFileN1]; 
        xbeeFilenames[i][2] = xbeeFilename[xbeeFileN2];  
        xbeeFilename[xbeeFileN1] = '0';
        xbeeFilename[xbeeFileN2] = '0';
        timer = millis();
        wait(setupDelay); 
    } 

    LED3.off();

  }
  else {
    LED5.on();
    xbee.enterATmode();      //Configure XBee as a reciever
    xbee.atCommand("ATRE");  //Reset to Default Parameters
    xbee.atCommand("ATCH" + channelID);
    xbee.atCommand("ATID" + networkID);
    xbee.atCommand("ATSC" + scanChID);
    xbee.atCommand("ATDL0"); //The DL and MY values of XBees that talk to each other should be inverted
    xbee.atCommand("ATMY1"); //Note how these are the reverse of the above settings for the relay unit
    //xbee.atCommand("ATD61");
    xbee.exitATmode();
    if(configStatus){
      unsigned int errorTimer = millis(); 
      counterID = 1;
      currentSwitchStatus = updateSwitchStatus();
      while (updateButtonStatus() == 0){
          if (updateSwitchStatus() != currentSwitchStatus){ // If switch is moved, add one to xbee ID
            counterID++;
            if (counterID < 11) xbeeID = xbeeID.substring(0, xbeeID.length()-1) + String(counterID);
            else xbeeID = xbeeID.substring(0, xbeeID.length()-2) + String(counterID);
            xbeeFilename[xbeeFileC] = char(counterID+64); // change the filename spot to corresponding char for each xbee, A is xbee 1, B is xbee 2, etc.
          }
          OLED.update("XBee ID:\n" + xbeeID + "\n" + String(xbeeFilename) + "\nMove S\nto add 1\n\nPress: B");
          Serial.println("XBee ID:" + xbeeID + "\nMove Swtich to add 1, Press Button to Skip");
          currentSwitchStatus = updateSwitchStatus();
          xbeeFilenames[counterID-1][0] = xbeeFilename[xbeeFileC]; 
          xbeeFilenames[counterID-1][1] = xbeeFilename[xbeeFileN1]; 
          xbeeFilenames[counterID-1][2] = xbeeFilename[xbeeFileN2]; 
          while (currentSwitchStatus == updateSwitchStatus() && updateButtonStatus() == 0){
            delay(20); // wait for a change in switch status or a button press
            if (millis() - errorTimer > errorDelay) break;
          }
          if (millis() - errorTimer > errorDelay) break;
      }
      logData(String(counterID), config);  // Log data to SD
    }
    else{
      for(int i=1; i<counterID; i++){
        xbeeFilename[xbeeFileC] = char(i+64); // change the filename spot to corresponding char for each xbee, A is xbee 1, B is xbee 2, etc.
        xbeeFilenames[i-1][0] = xbeeFilename[xbeeFileC]; 
        xbeeFilenames[i-1][1] = xbeeFilename[xbeeFileN1]; 
        xbeeFilenames[i-1][2] = xbeeFilename[xbeeFileN2]; 
      }
    }
    _print = (sdSetup(xbeeFilename, xbeeFileN1, xbeeFileN2) && sdActive) ? "SD Card   Online... Creating File... Logging to: " + String(xbeeFilename) : (sdActive) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
    Serial.println(_print);
    _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(xbeeFilename) : (sdActive) ? "NAFM\nClear SD\nSkip: B" : "SD\nFailed\nSkip: B";
    OLED.update(_print);
    xbeeFilenames[counterID-1][1] = xbeeFilename[xbeeFileN1]; 
    xbeeFilenames[counterID-1][2] = xbeeFilename[xbeeFileN2]; 
    timer = millis();
    wait(setupDelay);
    delay(100);

    _print = "Data String Recieved, Other";
    logData(_print, xbeeFilename);
    xbeeID = "X" + String(counterID);
    //updateXBee(header); 
  }

  logData("Start of Flight Bin,2,3,4,5,6,7,8", xbeeBin);
  
  _print = (sdSetup(xbeeSent, xbeeSentN1, xbeeSentN2) && sdActive) ? "SD Card   Online... Creating File... Logging to: " + String(xbeeSent) : (sdActive) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  Serial.println(_print);
  _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(xbeeSent) : (sdActive) ? "NAFM\nClear SD" : "SD\nFailed";
  OLED.update(_print);
  timer = millis();
  wait(setupDelay);
  logData("XBee Sent,2,3,4,5,6,7,8", xbeeSent);
  
  XBeeSerial.setTimeout(serialTimeout);
  xbee.setTimeout(serialTimeout);
  return isRelay;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void listenXBee(){
  String recievedID = "";
  byte split;  //question mark separates id from command

  //digitalWrite(27, LOW);  // turn the RST on LOW for to allow data to be sent to the Teensy
  //Just pipe data from computer to XBee
  while (Serial.available() > 0) {
      String serial = Serial.readStringUntil('\n');
      Serial.print(serial);
      XBeeSerial.print(xbeeID + IDterminator + serial + stringTerminator + String(inboxTerminator));
  }

  while (XBeeSerial.available() > 0) {
    LED3.on();
    //Serial.println(XBeeSerial.available());
    xbeeSerialData = buildString();
    //digitalWrite(27, HIGH);  // turn the RST on HIGH for flow control

    if (xbeeSerialData == "") return;        //No data was received 
    Serial.println(xbeeSerialData);  // for troubleshooting xbee messages

    if (xbeeSerialData.indexOf(IDterminator) != -1){ // If no IDterminator is found indexOf will return -1, so if it doesn't equal -1 continue
        split = xbeeSerialData.indexOf(IDterminator);  //question mark separates id from command
        recievedID = (xbeeSerialData.substring(0, split));
        //Serial.println(recievingID); // troubleshooting
        if (recievedID != xbeeID && !isRelay) break;
        xbeeSerialData = (xbeeSerialData.substring(split + 1, xbeeSerialData.length()-1));
        //Serial.println("Command ->" + xbeeSerialData); // troubleshooting
    }

    //LED3.off();

    if ((xbeeSerialData.substring(0,4)).equals("DATA")) { //Get full data string
        //xbeeSerialData = xbeeSerialData.substring(4);
        LED5.on();
        //XBeeSerial.print(xbeeID + IDterminator + data + stringTerminator + String(inboxTerminator));
        updateXBee(xbeeID + IDterminator + data + stringTerminator + String(inboxTerminator));
        xbeeMessage = "DATA STRING TRANSMITTED";
        LED5.off();
    }
    
    else if ((xbeeSerialData.substring(0,4)).equals("FLIP")) { //SYNC Command
        //numberOfXbees = (xbeeSerialData.substring(4, 5)).toInt();  //check to see how many xbees are linked
        //Serial.println(numberOfXbees);
        if (!LED4.status()){
            LED4.on();
        }
        else LED4.off();

        // xbeeSendValue = counterID;  // Code for Sync Command
        // xbeeRate = numberOfXbees;
        // xbeeTimer = 0;
        // if (!isRelay) delay(1500);
    }
      
    else if ((xbeeSerialData.substring(0,2)).equals("BL")) { //blink command
        byte times = (xbeeSerialData.substring(2, xbeeSerialData.length())).toInt();  //check to see how many times to blink
        for (; times > 0; times--) {
            LED4.on();
            delay(250);
            LED4.off();
            delay(250);
        }
    }
    else if (xbeeSerialData.equals("TIME"))  //report total time on command
        XBeeSerial.print(xbeeID + IDterminator + "Time on (ms): " + String(timer) + stringTerminator + String(inboxTerminator));
  
      //Serial.println(int(recievingID[4])-48-1); // Troubleshooting
    if (recievedID != "" && (recievedID.substring(0, indexOfIntID)).equals(xbeeID.substring(0, xbeeID.length()-1))){
        byte var = int(recievedID[indexOfIntID])-48-1;
        //if (isRelay){
            xbeeFilename[xbeeFileC] = xbeeFilenames[var][0];
            xbeeFilename[xbeeFileN1] = xbeeFilenames[var][1];
            xbeeFilename[xbeeFileN2] = xbeeFilenames[var][2];
        //}
        if(xbeeSerialData.length()<30){
            xbeeSerialData += "," + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + "," +
                              String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond);
            logData(recievedID + "," + xbeeSerialData, xbeeBin);
        }
        else  logData(xbeeSerialData, xbeeFilename);
    }
    else  {
        xbeeSerialData += "," + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + "," +
                          String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond);
        logData(xbeeSerialData, xbeeBin);
    }

    //Serial.println(xbeeSerialData);
    xbeeSerialData = ""; // delete the data that was recieved
    LED3.off();
  }
  //digitalWrite(27, HIGH);  // turn the RST on HIGH for flow control
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void updateXBee(String Data){
  //String newData = Data;
  bool LEDstat = 0;
  if(LED5.status()) {
    LED5.on();
    LEDstat = 1;
  }
  else LED5.on();
  // if(Data.length() > stringLen){
  //     XBeeSerial.print(xbeeID + IDterminator + "DATA" + Data.substring(0,stringLen));
  //     Data = Data.substring(stringLen);
  //     delay(10);
  //     while(Data.length() > stringLen){
  //         XBeeSerial.print(Data.substring(0,stringLen));
  //         Data = Data.substring(stringLen);
  //         delay(10);
  //     }
  //     XBeeSerial.print(Data.substring(0,stringLen) + stringTerminator + String(inboxTerminator));
  //     delay(10);
  // }
  // else XBeeSerial.print(xbeeID + IDterminator + Data + "\n" + String(inboxTerminator));
  //XBeeSerial.print(xbeeID + IDterminator + Data + stringTerminator + String(inboxTerminator));
  Serial.println(Data);
  XBeeSerial.print(Data);
  if(Data.length()<30){
      Data += "," + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + "," +
                    String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond);
      logData(Data, xbeeSent);
  }
  //xbeeMessage = "DATA REQUEST SENT";
  //delay(20);
  if(!LEDstat) LED5.off();
}

String buildString(){
  unsigned long xbeeDataTimer = millis(); //soft pause for thisfunction
  String command = XBeeSerial.readStringUntil(inboxTerminator);
  if (command.equals("")) return "";
  if (command.equals("+++")) return "+++";
  if (command.indexOf(IDterminator) == -1) return command; // If no IDterminator is found indexOf will return -1 and the function will exit with the command
  // while ((command.substring(0,6)).indexOf(IDterminator) != -1 && command.indexOf(IDterminator) == command.lastIndexOf(IDterminator) && millis() - xbeeDataTimer < 800){
  //     command += XBeeSerial.readStringUntil(inboxTerminator);
  // }
  if (command.substring(command.length()-1) != stringTerminator){
    while(command.substring(command.length()-1) != stringTerminator && millis() - xbeeDataTimer < 800){
        //Serial.println(command.substring(command.length()-1));
        //Serial.println(command);
        command += XBeeSerial.readStringUntil(inboxTerminator);
    }
  }
  //Serial.println("Command -> " + command); // Print command for testing purposes
  return command;
}

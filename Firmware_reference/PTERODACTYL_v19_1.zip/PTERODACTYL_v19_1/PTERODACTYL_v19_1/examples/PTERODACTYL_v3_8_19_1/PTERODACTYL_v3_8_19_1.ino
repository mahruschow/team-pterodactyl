/************************************************
      MnSGC Ballooning PTERODACTYL Flight Code
      Created by: Ashton Posey
                  Seyon Wallo
                  Paul Wehling
                  Andrew Van Gerpen
      Modification Date: 1/14/24
************************************************/
//Purpose: Code for the PTERODACTYL Flight Computer
#define Version "Version 3.8.19.1"

// Libraries for PTERODACTY all located at: https://drive.google.com/drive/folders/1nN36iX2q5jVoLVoVwVqiJ_1dIJBKqOAI?usp=sharing 
#include <PT_LED.h>          // Custom Library to use LED's
#include <PT_Thermistor.h>   // Custom Library to use Thermistors
#include <PT_OLED.h>         // Custom Library to use OLED
#include <PT_MS5611.h>       // Custom Library to use MS5611
#include <SparkFunLSM9DS1.h> // https://github.com/sparkfun/SparkFun_LSM9DS1_Arduino_Library
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h> // https://github.com/adafruit/Adafruit_BNO055
#include <utility/imumaths.h>
#include <SparkFun_u-blox_GNSS_Arduino_Library.h> //http://librarymanager/All#SparkFun_u-blox_GNSS
#include <XBee.h>            // Located in PTERODACTYL Code folder
#include <SoftwareSerial.h>  // All these Libraries are included with Arduino \/
#include <OneWire.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>  //// IF SD.h FOR THE ARDUINO IS IN YOUR LIBRARIES FOLDER THE CODE MIGHT NOT COMPILE ////

#define SERIAL_BAUD 500000           // When using arduino serial monitor, make sure baud rate is set to this same value
#define I2C_CLOCK 400000
#define CHIP_SELECT BUILTIN_SDCARD   // Available for Teensy 3.5/3.6/4.0/4.1
#define SWITCH_PIN 30         
#define BUTTON_PIN 31 
#define UBLOX_SERIAL Serial2
#define DECLINATION 0.16 // Declination (degrees) in St. Paul, MN.
#define VOLTAGE_READER_PIN 26
// #define R1_ACTUAL 4550.0 // Ohms
// #define R2_ACTUAL 990.0  // Ohms
#define R1_THEORETICAL 4700.0
#define R2_THEORETICAL 1000.0

#define OK(ok) (ok ? F("  ->  OK") : F("  ->  ERROR!")) // Convert uint8_t into OK/ERROR

float inputVoltage = 999;

bool currentSwitchStatus; // Allows for wait until switch changes position to do something

// SdFs Sd;          // SD Fat Application
// FsFile datalog;
// SdFat32 Sd;
// File32 datalog;
// SdExFat Sd;
// ExFile datalog;

// SD Logging
File datalog; // Constructed object that handles SD input and output, can input/output i.e read/write for multiple files
char dataFilename[ ] = "PTER00.csv"; //Make sure dataFileN matches first and second place of the zeros in terms of the arrays index
const byte dataFileN1 = 4; 
const byte dataFileN2 = 5; 
// char oneHzFilename[ ] = "1HZ00.csv"; //Make sure dataFileN matches first and second place of the zeros in terms of the arrays index
// const byte oneHzFileN1 = 3;
// const byte oneHzFileN2 = 4;
char xbeeFilename[ ] = "XBA00.csv"; // 4th and 5th place so 3 & 4 in array terms
const byte xbeeFileC = 2; // Index of char that will be changed for each xbee, xbee 1 is A, xbee 2 is B, etc.
const byte xbeeFileN1 = 3;
const byte xbeeFileN2 = 4;
char xbeeSent[ ] = "SENT00.csv"; // 4th and 5th place so 3 & 4 in array terms
const byte xbeeSentN1 = 4;
const byte xbeeSentN2 = 5;
char xbeeBin[ ] = "XBin.csv"; // All non ID commands will be logged here.
char xbeeFilenames[10][3];   // Stores the values of 00 in the file name so that it can log the correct xbee to the correct file
bool sdStatus = false; // Status of datalog.begin();     
bool sdActive = false; // Status of if there are available file names i.e the SD could be full from files 0-100

byte dataCounter = 0;
String dataAdded = "";

// LEDs
LED LED1(LED_BUILTIN);
LED LED2(2); // Send pins that the LED's are using in class LED
LED LED3(3); // On the PCB the LED's are labled with the pins they're connected to on the Teensy
LED LED4(4); // LED 1 : Data Update : LED 2 : Switch On or Off
LED LED5(5); // LED 3 : SD Status   : LED 4 : XBee Update

// Thermistors
Thermistor ThermistorInt(40);   // Pins that the Thermistors are using in class Thermistor
Thermistor ThermistorExt(41);

// MS5611 Pressure Sensor
MS5611 MS5611; // Construct MS5611 Pressure Sensor object in class MS5611
bool msStatus = true; // will be changed in the set up

// IMU's
LSM9DS1 lsm;//                        id, I2C address, &Wire or &Wire1 or &Wire2
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire);
bool lsmStatus = false;
bool bnoStatus = false;
String imuType = "LSM";
float magnetometer[3] = {999, 999, 999};  // {x, y, z}
float accelerometer[3] = {999, 999, 999}; // {x, y, z}
float gyroscope[3] = {999, 999, 999};     // {x, y, z}
float orientation[3] = {999, 999, 999};   // {yaw (rotation about z axis), roll (rotation about y axis), pitch (rotation about x axis)}

// UBLOX GPS
SFE_UBLOX_GNSS sparkFunGNSS;

String gpsType = "N/A";  // In order to output M9N to OLED to change between M9N & M8N
int gpsBaud = 38400;     // 9600 for M8N But that doesn't really matter since the code let's the user decide which gps to use
unsigned long gpsTimer = 0;

byte gpsStatus = 0;
//bool hpGPS = false;
int gpsMonth = 999;
int gpsDay = 999;
int gpsYear = 999;
int gpsHour = 999;
int gpsMinute = 999;
int gpsSecond = 999;
int gpsMillisecond = 999;
int gpsTimeOfWeek = 999;
double gpsLat = 999;
double gpsLon = 999;
double gpsAltM = 999;
double gpsAltFt = 999;
double gpsGndSpeed = 999;
double gpsHeading = 999;
double gpsPDOP = 999;

long gpsLatDec = 999;
int gpsLatInt = 999;
long gpsLonDec = 999;
int gpsLonInt = 999;

bool gpsFast = 0;

//High Percision GPS
float altitudeFtGPS = 999;
float latitudeGPS = 999;
float longitudeGPS = 999;
//initializaiton of ECEF variables
long ecefX = 999, ecefY = 999, ecefZ = 999;
double posAcc = 999;
int SIV = 0;
double latCalc = 999, longCalc = 999, altCalcFt = 999;
//UTM vairabels:
double UTMNorthing = 999, UTMEasting = 999;
char UTMZoneLetter = '?';
int UTMZoneNum = 999;

int setDynModel = 0;

bool pvtStatus = false;
bool ecefStatus = false;
bool lbandStatus = false;

bool rtkEnabled = false;
bool gpsI2C = 0;

double gpsVertVelFt = 999;
double gpsVertVelM = 999;
unsigned long gpsPrevTime = 0;
double gpsPrevAlt = 0;

double velocityNED[3] = {999,999,999};

int gpsHorizAcc = 999;
int gpsVertAcc = 999;

String fixTypeGPS = "N/A"; // create an empty string called msgStr with a capacity if 40 chars
String fixTypeRTK = "N/A"; // create an empty string called msgStr with a capacity if 40 chars

SFE_UBLOX_GNSS myLBand; // NEO-D9S

const uint32_t myLBandFreq = 1556290000; // Uncomment this line to use the US SPARTN 1.8 service

bool rxmStatus = false;

// OLED
OLED OLED;   // Input the pins that the MS5611 is using
String strOLED, strOLED2;
bool oledOn = true;

//XBee Global Variables
SoftwareSerial XBeeSerial = SoftwareSerial(34, 35);  //Pins to communicate with XBee
XBee xbee(&XBeeSerial); //            DOUT RX  TX DIN
String channelID = "10";
String networkID = "A100";   // AAAA, BBBB, CCCCC, etc. change if there are multiple networks of xbees on the balloon fliight
int counterID = 0;           // Value of number of reciever xbees in the network, for reciever this will be set to the value in the ID

bool isRelay = false;
String xbeeMessage;
byte xbeeRate = 1;           // how many loops until it sends another data string
byte xbeeTimer = 1;          // xbeeRate - xbeeTimer = what loop the first command is sent on
byte xbeeTimerStart = 0;     // what number the loop starts at: should be 0
byte xbeeSendValue = 1;      // can be a different value than xbeeRate, then the xbee will send on that value of xbeeTimer but only every xbeeRate
byte numberOfXbees = 1;      // Total number of xbees on network
String xbeeID = "X1";        //Choose an ID for your XBee - 2-4 character string, A-Z and 0-9 with 1 at the end 
const byte indexOfIntID = 1; // Index of the 1 in at the end of the ID
const char inboxTerminator = '&';    // Make sure that not too much is being taken from the XBees inbox
const String IDterminator = "?";     // Make sure the ID can be taken out of recieved String
const String stringTerminator = "!"; // Make sure the code knows when a full string has been built

// Data Logging
String header = "T(h:m:s),FT(h:m:s),T(Sec),T(ms),UF(Hz),T2,T5,T7,T8,VIN(V),FixType,FixRTK,PVT,Sats,Date,Time,Lat,Lon,Alt(Ft),Alt(M),HorizAccu(MM),VertAccu(MM),VV(Ft/S),VV(M/S),ECEF,ECEF X(CM),ECEF Y(CM),ECEF Z(CM),Zone#,Easting,Northing,NedVelNorth(M/S),NedVelEast(M/S),NedVelDown(M/S),GndSpd(M/S),Head(Deg),PDOP,htrT(F),htrStat,intT(C),intT(F),extT(C),extT(F),msTemp(C),msTemp(F),msPress(MBar),msPress(PSI),msPress(ATM),msAlt(ft),msAlt(M),VertVel(Ft/S),VertVel(M/S),mag x,mag y,mag z,accel x,accel y,accel z,gyro x,gyro y,gyro z,orien yaw,orien pitch,orien roll,xbee message," + String(Version);
String _print;

//Timer
String fullTimer = "NA:NA:NA";         // millis() turned into a flight timer String format, shouldn't read as N/A:N/A:N/A on serial monitor
unsigned long timer = 0;                  // Stored millis() value, used for dataDelay's soft pause
float timerSec = 0;                       // Stored millis() / 1000 value for seconds
unsigned int buttonTimer = 0;             // Soft Pause for button to send flip command

unsigned int timer2 = 0;
unsigned int timer3 = 0;
unsigned int timer4 = 0;
unsigned int timer5 = 0;
unsigned int timer6 = 0;
unsigned int timer7 = 0;
unsigned int timer8 = 0;
unsigned int timerTotal = 0;

//Flight Timer
String flightTimerString = "NA:NA:NA"; // Initial value of flight timer, before flight starts, then outputs millis()-flightStartTime as flight timer String
unsigned long flightStartTime = 0;        // Value in millis of when the flight starts
bool flightTimerStatus = false;           // Status for if the flight starts
float altFtStart = 0;                     // Alt of the payload when the payload is turned on, is compared against current alt to start flight timer

//Code Delay Time milliseconds
unsigned int dataDelay = 100;        // Delay inbetween every time dataUpdate is called which updates the full data string and all onboard sensors -> This delay is always modified in the HP GPS Tab
const unsigned int setupDelay = 500;      // If Setup commands are running too fast to see on the OLED increase this delay
const unsigned int xbeeDelay = 1000;       // Delay inbetween every xbee 'ask' for data from reciever
unsigned long xbeeTimerSec;               // Stored value of millis() to compare against xbeeDelay
const unsigned int oneHzDelay = 1000;      // Delay to store data every one sec / mainly useful for HP Code
unsigned long oneHzTimer;                 // Stored value of millis() to compare against oneHzDelay
const unsigned int oledDelay = 5000;      // Delay inbetween each oled screen switch
unsigned long oledTimer;                  // Stored value of millis() to compare against oledDelay
unsigned int oledCounter = 0;
unsigned int oledCounterMax = 6;
const unsigned int errorDelay = 30000;

//Configuration Variables
char config[ ] = "Configuration.txt";
bool configStatus;
const unsigned int configDelay = 15000;    // Delay inbetween each oled screen switch
unsigned long configTimer;                // Stored value of millis() to compare against oledDelay
unsigned int configCounter = 0;           // Should be one less 


// updateFrequency function
unsigned long pastTime = 0;
float frequencyHz = 0;

String data = "No Data";

//Heater
#define heaterSet 28
#define heaterReset 29

Thermistor ThermistorHeater(20);

//float heaterTempValue; // This will be set by some sensor read function. Just pretend this variable always has the temperature
float minimumTemperature = 80;
float maximumTemperature = 90; // all of these are redudant, but allows for changing of maximum/min temp as opposed to having max temp be just = to tolerance

String heaterStatus = "N/A";
bool usingHeater = 0;

unsigned int error = 0;

///////////////////////////////////////////////// SETUP /////////////////////////////////////////////////
void setup() {
  ////////////////////////////////////// Initial System Set Up //////////////////////////////////////
  Serial.begin(SERIAL_BAUD); //define baud rate in variable decleration above
  Serial.println("Serial    Online!");

  LED1.begin(); // Initilize all LED's with class LED 
  LED2.begin();
  LED3.begin();
  LED4.begin();
  LED5.begin();

  LED1.on();

  int ledDelay = 100;

  LED2.on();
  delay(ledDelay);
  LED3.on();
  delay(ledDelay);
  LED2.off();
  LED5.on();
  delay(ledDelay);
  LED3.off();
  LED4.on();
  delay(ledDelay);
  LED5.off();
  LED2.on();
  delay(ledDelay);
  LED4.off();
  delay(ledDelay);
  LED2.off();
  
  pinMode(BUTTON_PIN, INPUT_PULLUP); // Initialize the momentary switch (push button) pin as an input, labled pin 31 on PCB
  pinMode(SWITCH_PIN, INPUT_PULLUP); // Initialize the switch pin as an input, labled 30 on PCB

  Wire.begin();
  Wire.setClock(I2C_CLOCK);

  Wire1.begin();
  Wire1.setClock(I2C_CLOCK);
  
  OLED.begin();
  OLED.update("Init...");
  wait(setupDelay); // Soft pause for when everything is online
  delay(300);
  Wire.setClock(I2C_CLOCK);

  ////////////////////////////////////// SD Card Set Up //////////////////////////////////////
  _print = (sdSetup(dataFilename, dataFileN1, dataFileN2) && sdActive) ? "SD Card   Online! Creating File... Logging to: " + String(dataFilename) : (sdStatus) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  Serial.println(_print);
  _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(dataFilename) : (sdStatus) ? "NAFM\nClear SD\n\n\n\nSkip: B" : "SD\nFailed\n\n\n\nSkip: B";
  OLED.update(_print);
  if (!sdStatus || !sdActive) LED4.on();
  if (!sdStatus || !sdActive) while(!updateButtonStatus()) delay(20);
  wait(setupDelay);
  delay(500);
  // _print = (sdSetup(oneHzFilename, oneHzFileN1, oneHzFileN2) && sdActive) ? "SD Card   Online! Creating File... Logging to: " + String(oneHzFilename) : (sdStatus) ? "No available file names; clear SD card to enable logging" : "Card failed, or not present";  
  // Serial.println(_print);
  // _print = (sdStatus && sdActive) ? "Logging:\n\n" + String(oneHzFilename) : (sdStatus) ? "NAFM\nClear SD\n\n\n\nSkip: B" : "SD\nFailed\n\n\n\nSkip: B";
  // OLED.update(_print);
  // if (!sdStatus || !sdActive) LED3.on();
  // if (!sdStatus || !sdActive) while(!updateButtonStatus()) delay(20);
  // wait(setupDelay);
  // delay(500);
  
  ////////////////////////////////////// Thermistor Set Up //////////////////////////////////////
  while (ThermistorInt.getStatus() == 0 || ThermistorExt.getStatus() == 0){
      if(millis()-timer > 250){
          _print = (ThermistorInt.begin(12) && ThermistorExt.begin(12)) ? "Therm Int Online!\nTherm Ext Online!" : ThermistorInt.getStatus() ? "Therm Int Online!\nTherm Ext Offline...Skip: B\nRetry: S" : ThermistorExt.getStatus() ? "Therm Int Offline...\nTherm Ext Online!\nSkip: B\nRetry: S" : "Therm Int Offline...Therm Ext Offline...Skip: B\nRetry: S";
          Serial.println(_print);  // Since this is a Teensy we are using, the read bit resolution can be at a max of 13 (12 for Teensy 4.1).
          OLED.update(_print);     // The maximum adc value given to the thermistor, should be 8191 (2^13) for a Teensy 3.6, 
          timer = millis();        // 4095 (2^12) for a Teensy 4.1, and 1023 (2^10) for an Arduino
      }
      if(ThermistorInt.getStatus() == 0 || ThermistorExt.getStatus() == 0) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
  }
  wait(setupDelay);
  delay(300);
  
  ////////////////////////////////////// Configuration Set Up //////////////////////////////////////
  configTimer = millis();
  OLED.update("Using New\nConfig?\nYes: S on\nNo: S off\n\nPress B");
  Serial.println("Using New Configuration on the PTERODACTYL Hardware?   Yes: Switch on   No: Switch off   Press Button to continue");
  while (updateButtonStatus() == 0 && millis() - configTimer <= configDelay) {
      if(updateSwitchStatus()){
          LED3.on();
          LED5.off();
          configStatus = true;
          OLED.update("Using New\nConfig?\nYes: S on+No: S off\n\nPress B");
      }
      if(!updateSwitchStatus()){
          LED5.on();
          LED3.off();
          configStatus = false;
         OLED.update("Using New\nConfig?\nYes: S on\nNo: S off+\nPress B");
      }
      delay(20);
  }
  if (millis() - configTimer > configDelay){
    configStatus = false;
  }
  //Serial.println(configStatus);
  LED5.off();
  LED3.off();
  delay(250);
  if (!configStatus){
    datalog = SD.open(config);
    //datalog.open(config);
    if(!datalog.available()) {
      configStatus = true;
      OLED.update("No Config\nFound\nCheck SD");
      delay(1000);
    }
    else{
      if (datalog) {
      //Serial.print("Reading ...");
      //Serial.println(filename);
      String str = "";
      String fullString = "";
        while (datalog.available()) {
          str = datalog.read();
          //Serial.println(str);
          //integer = str.toInt();
          fullString += str;
            if (str == "\n") {
              configCounter++;
              if(configCounter == 1) usingHeater = fullString.toInt();
              else if(configCounter == 2) msStatus = fullString.toInt();
              else if(configCounter == 3) imuType = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 4) lsmStatus = fullString.toInt();
              else if(configCounter == 5) bnoStatus = fullString.toInt();
              else if(configCounter == 6) gpsFast = fullString.toInt();
              else if(configCounter == 7) rtkEnabled = fullString.toInt();
              else if(configCounter == 8) gpsI2C = fullString.toInt();
              else if(configCounter == 9) gpsType = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 10) gpsBaud = fullString.toInt();
              else if(configCounter == 11) channelID = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 12) networkID = fullString.substring(0,fullString.length()-1);
              else if(configCounter == 13) isRelay = fullString.toInt();
              else if(configCounter == 14) counterID = fullString.toInt();
              //Serial.print(fullString);
              //Serial.print(" ");
              //Serial.println(configCounter);
              fullString = "";
            }
        }
      }
    }
    datalog.close();
  }
  else {
    SD.remove(config); //Delete all data from config file
    //Sd.remove(config); //Delete all data from config file
    //datalog.close();
  }

  if(!configStatus){
    Serial.print("Using Heater "); Serial.println(usingHeater);
    Serial.print("MS5611       "); Serial.println(msStatus);
    Serial.print("IMU Type     "); Serial.println(imuType);
    Serial.print("LSM Status   "); Serial.println(lsmStatus);
    Serial.print("BNO Status   "); Serial.println(bnoStatus);
    Serial.print("GPS Fast     "); Serial.println(gpsFast);
    Serial.print("GPS RTK      "); Serial.println(rtkEnabled);
    Serial.print("GPS I2C      "); Serial.println(gpsI2C);
    Serial.print("GPS Type     "); Serial.println(gpsType);
    Serial.print("GPS Baud     "); Serial.println(gpsBaud);
    Serial.print("Channel      "); Serial.println(channelID);
    Serial.print("Network      "); Serial.println(networkID);
    Serial.print("Relay        "); Serial.println(isRelay);
    Serial.print("XBee Counter "); Serial.println(counterID);
  }

  ////////////////////////////////////// Heater Set Up //////////////////////////////////////
  if(configStatus){
    OLED.update("Creating\nNew\nConfig");
    delay(1000);
      OLED.update("Using\nHeater?\nYes: S on\nNo: S off\n\nPress B");
      Serial.println("Using a Power Plane Heater?   Yes: Switch on   No: Switch off   Press Button to continue");
      unsigned int errorTimer = millis();
      while (updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              usingHeater = true;
              OLED.update("Using\nHeater?\nYes: S on+No: S off\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              usingHeater = false;
            OLED.update("Using\nHeater?\nYes: S on\nNo: S off+\nPress B");
          }
          delay(20);
          if (millis() - errorTimer > errorDelay) {
            usingHeater = false;
            break;
          }
      }
      logData(String(usingHeater), config);  // Log data to SD
      LED5.off();
      LED3.off();
  }
  if(usingHeater) heaterSetup();
  else{
      //Serial.println(header.indexOf("htrT(F),htrStat,")-1);
      _print = header.substring(0, header.indexOf("htrT(F),htrStat,")-1);
      header = _print + header.substring(header.indexOf("htrT(F),htrStat,")-1 + 16, header.length());
      //Serial.println(header);
  }
  delay(250);

  ////////////////////////////////////// MS5611 Pressure Sensor Set Up //////////////////////////////////////
  if(configStatus){
      unsigned int errorTimer = millis();
      OLED.update("Using\nMS5611?\nYes: S on\nNo: S off\n\nPress B");
      Serial.println("Using MS5611   Yes: Switch on   No: Switch off   Press Button to continue");
      while (updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              msStatus = true;
              OLED.update("Using\nMS5611?\nYes: S on+No: S off\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              msStatus = false;
            OLED.update("Using\nMS5611?\nYes: S on\nNo: S off+\nPress B");
          }
          delay(20);
          if (millis() - errorTimer > errorDelay){
            msStatus = true;
            break;
          }
      }
      logData(String(msStatus), config);  // Log data to SD

      LED5.off();
      LED3.off();
      delay(250);
  }

  _print = (msStatus && MS5611.begin()) ? "MS5611    Online!" : "MS5611    Offline...\n\n\nSkip: B";
  Serial.println(_print);
  OLED.update(_print);
  if (msStatus) {
    MS5611.update();
    MS5611.setOversampling(MS5611_ULTRA_HIGH_RES);
  }
  /*
  There are 5 oversampling settings, each corresponding to a different amount of milliseconds
  The higher the oversampling, the more accurate the reading will be, however the longer it will take.
  MS5611_ULTRA_HIGH_RES -> 22 millis
  MS5611_HIGH_RES      -> 11 millis
  MS5611_STANDARD   -> 5.5 millis
  MS5611_LOW_POWER       -> 2.75 millis
  MS5611_ULTRA_LOW_POWER  -> 1.375 millis   Default = backwards compatible
  */
  while (!msStatus && !updateButtonStatus()) delay(20); 
  if (msStatus) altFtStart = MS5611.msAltitudeFt;
  wait(setupDelay);
  delay(300);
  
  ////////////////////////////////////// BNO or LSM IMU Set Up //////////////////////////////////////
  if(configStatus){
      unsigned int errorTimer = millis();
      OLED.update("IMU Type:\nLSM: S on\nBNO:S off\n\n\nPress B");
      Serial.println("IMU Type:   LSM: Switch On   BNO: Switch Off   Press Button to Continue");
        while (updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              imuType = "LSM";
              lsmStatus = true;
              bnoStatus = false;
              OLED.update("IMU Type:\nLSM: S on+BNO:S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              imuType = "BN0";
              lsmStatus = false;
              bnoStatus = true;
              OLED.update("IMU Type:\nLSM: S on\nBNO:S off+\n\nPress B");
          }
          if (millis() - errorTimer > errorDelay) {
            imuType = "BN0";
            lsmStatus = false;
            bnoStatus = true;
            break;
          }
          delay(20);
      }
      LED3.off();
      LED5.off();
      delay(150);
  }

  bool workingIMU = false;
  int workingIMUCounter = 0;
  while(workingIMU == false && workingIMUCounter <= 4){
      if(lsmStatus){
          unsigned int errorTimer = millis();
          lsmStatus = false;
          while(!lsmStatus){
              lsmStatus = (lsm.begin()) ? true : false;
              _print = (lsmStatus) ? "LSM9DS1   Online!" : "LSM9DS1   Offline...\n\nSkip: B\nRetry: S";
              Serial.println(_print);
              OLED.update(_print);
              if (lsmStatus) {
                workingIMU = true;
                break;
              }
              while(updateButtonStatus() == 0 && updateSwitchStatus() == 0){
                 delay(20);
                 if (millis() - errorTimer > errorDelay){
                    bnoStatus = true;
                    break;
                 }
              }
              if (updateButtonStatus()) break;
              if (millis() - errorTimer > errorDelay){
                    bnoStatus = true;
                    break;
              }
              delay(100);
          }
      }
      else if(bnoStatus){
          unsigned int errorTimer = millis();
          bnoStatus = false;
          while(!bnoStatus){
              bnoStatus = (bno.begin()) ? true : false;
              _print = (bnoStatus) ? "BNO055    Online!" : "BNO055    Offline...\n\nSkip: B\nRetry: S";
              Serial.println(_print);
              OLED.update(_print);
              if (bnoStatus){
                workingIMU = true;
                break;
              }
              while(updateButtonStatus() == 0 && updateSwitchStatus() == 0){
                  delay(20);
                  if (millis() - errorTimer > errorDelay){
                    lsmStatus = true;
                    break;
                  }
              }
              if (updateButtonStatus()) break;
              if (millis() - errorTimer > errorDelay){
                    lsmStatus = true;
                    break;
              }
              delay(100);
          }
      }
      if (updateButtonStatus()) break;
      workingIMUCounter++;
  }

  if (configStatus){
      logData(imuType, config);  // Log data to SD
      logData(String(lsmStatus), config);  // Log data to SD
      logData(String(bnoStatus), config);  // Log data to SD
  }

  wait(setupDelay);
  delay(300);

  ////////////////////////////////////// GPS Set Up //////////////////////////////////////
  if(configStatus){ // If it's not already configured, configure it manually
      unsigned int errorTimer = millis();
      OLED.update("Fast GPS?\nYes: S on\nNo: S off\n\n\nPress B");
      Serial.println("Is the GPS Running In A Fast Mode? Yes: Switch On   No: Switch Off   Press Button to Continue");
      while(updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              gpsFast = true;
              OLED.update("Fast GPS?\nYes: S on+No: S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              gpsFast = false;
              OLED.update("Fast GPS?\nYes: S on\nNo: S off+\n\nPress B");
          }
          delay(20);
          if (millis() - errorTimer > errorDelay) { // Check to see if it's taking too long
            gpsFast = true;
            break;
          }
      }
      logData(String(gpsFast), config);  // Log data to SD
      LED5.off();
      LED3.off();
      delay(300);
  }
  //if(!gpsFast){
          //Serial.println(header.indexOf("ECEF X,ECEF Y,ECEF Z,Zone#,Easting,Northing,GndSpd(M/S),Head(Deg),PDOP,")-1);
          // _print = header.substring(0, header.indexOf("ECEF X,ECEF Y,ECEF Z,Zone#,Easting,Northing,")-1);
          // header = _print + header.substring(header.indexOf("ECEF X,ECEF Y,ECEF Z,Zone#,Easting,Northing,")-1 + 44, header.length()); //71
          //Serial.println(header);
  //}
  if(configStatus){ // If it's not already configured, configure it manually
      unsigned int errorTimer = millis();
      OLED.update("RTK GPS?\nYes: S on\nNo: S off\n\n\nPress B");
      Serial.println("Is the GPS Using the D9S Corrections Reciever Module for RTK? Yes: Switch On   No: Switch Off   Press Button to Continue");
      while(updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              rtkEnabled = true;
              OLED.update("RTK GPS?\nYes: S on+No: S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              rtkEnabled = false;
              OLED.update("RTK GPS?\nYes: S on\nNo: S off+\n\nPress B");
          }
          delay(20);
          if (millis() - errorTimer > errorDelay) { // Check to see if it's taking too long
            rtkEnabled = false;
            break;
          }
      }
      logData(String(rtkEnabled), config);  // Log data to SD
      LED5.off();
      LED3.off();
      delay(300);
  }

  if(configStatus){ // If it's not already configured, configure it manually
      unsigned int errorTimer = millis();
      OLED.update("GPS I2C:\nYes: S on\nNo: S off\n\n\nPress B");
      Serial.println("Is the GPS Running off of I2C? Yes: Switch On   No: Switch Off   Press Button to Continue");
      while(updateButtonStatus() == 0) {
          if(updateSwitchStatus()){
              LED3.on();
              LED5.off();
              gpsI2C = true;
              OLED.update("GPS I2C:\nYes: S on+No: S off\n\n\nPress B");
          }
          if(!updateSwitchStatus()){
              LED5.on();
              LED3.off();
              gpsI2C = false;
              OLED.update("GPS I2C:\nYes: S on\nNo: S off+\n\nPress B");
          }
          delay(20);
          if (millis() - errorTimer > errorDelay) {
            gpsI2C = true;
            break;
          }
      }
      logData(String(gpsI2C), config);  // Log data to SD
      if(gpsI2C){
        logData("M9", config);  // Log data to SD
        logData("0", config);  // Log data to SD
        gpsType = "M9";
        gpsBaud = 0;
      }
      LED5.off();
      LED3.off();
      delay(300);
  }
  
  if(!gpsI2C){
    if(configStatus){ // If it's not already configured, configure it manually
        unsigned int errorTimer = millis();
        OLED.update("GPS Type:\nM9: S on\nM8: S off\n\n\nPress B");
        Serial.println("GPS Type:   M9N: Switch On   M8N: Switch Off   Press Button to Continue");
        while(updateButtonStatus() == 0) {
            if(updateSwitchStatus()){
                LED3.on();
                LED5.off();
                gpsType = "M9";
                gpsBaud = 38400;
                OLED.update("GPS Type:\nM9: S on +M8: S off\n\n\nPress B");
            }
            if(!updateSwitchStatus()){
                LED5.on();
                LED3.off();
                gpsType = "M8";
                gpsBaud = 9600;
                OLED.update("GPS Type:\nM9: S on\nM8: S off+\n\nPress B");
            }
            delay(20);
            if (millis() - errorTimer > errorDelay) {
              gpsType = "M9";
              gpsBaud = 38400;
              break;
            }
        }
        logData(gpsType, config);  // Log data to SD
        logData(String(gpsBaud), config);  // Log data to SD
        LED5.off();
        LED3.off();
        delay(300);
    }
  }
  //Serial.println(gpsBaud);
  while(gpsStatus != 7){
      _print = (setupHPGPS() == 7) ? gpsType + " GPS    Online!" : gpsType + " GPS    Offline...\n\nSkip: B\nRetry: S";
      Serial.println(_print);
      OLED.update(_print);
      if(gpsStatus != 7) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
      delay(20);
  }
  //Serial.println(gpsFast);
  // if (!gpsFast && gpsStatus > 0){
  //     gpsStatus = 1;
  //     dataDelay = 1000;
  // }
  wait(setupDelay);
  delay(400);

  ////////////////////////////////////// XBee Set Up //////////////////////////////////////
  OLED.update("\n\n   XBee\n   Setup");
  _print = (xBeeSetup()) ? "XBee      Relay..." : "XBee      Reciever..";
  Serial.println(_print);
  OLED.update(_print);
  wait(setupDelay);
  delay(300);

  ////////////////////////////////////// Final System Set Up //////////////////////////////////////
  logData(header, dataFilename); // Log header to SD Card -> Check to make sure the PTERODACTYL got through set up
  // logData(header, oneHzFilename);
  Serial.println(header);
  LED1.off();

  Wire.setClock(I2C_CLOCK);
  Wire1.setClock(I2C_CLOCK);
  oledTimer = millis(); // Set timer up to have an adaquate delay
  timer = millis(); // 
}

///////////////////////////////////////////////// LOOP /////////////////////////////////////////////////
void loop() {
  if (updateButtonStatus()) LED5.on();
  else LED5.off();

  if (updateSwitchStatus()) { 
      LED3.on();
      oledTimer = millis();
  }
  else LED3.off();

  listenXBee();

  if (updateButtonStatus() && millis() - buttonTimer >= 250) { // Check if the button is pressed to send command.
      updateXBee("FLIP");                                     // Only soft pause that can use buttonTimer in loop
      buttonTimer = millis();
      oledCounter++;
      if (oledCounter == oledCounterMax) oledCounter = 0;
      oledTimer = millis();
  }

  if(millis() - oledTimer >= oledDelay) { // Only soft pause that can use oledTimer in loop
      oledTimer = millis();
      oledCounter++;
      if (oledCounter == oledCounterMax) oledCounter = 0;
  }
  
  if(millis() - timer >= dataDelay) { // Only soft pause that can use timer in loop
      timer = millis();
      dataUpdate();
  }

  // if(rtkEnabled){
  //     sparkFunGNSS.checkUblox(); // Check for the arrival of new GNSS data and process it.
  //     sparkFunGNSS.checkCallbacks(); // Check if any GNSS callbacks are waiting to be processed.
  // }

  // if(millis() - oneHzTimer >= oneHzDelay) { // Log data at 1 Hz to 1HZ file
  //     oneHzTimer = millis();
  //     logData(data, oneHzFilename);
  // }

  if(millis() - xbeeTimerSec >= xbeeDelay && isRelay) { // Send an ask for data to the reciever units in hopes of recieving a data string
      if (xbeeRate != 0) updateXBee(xbeeID.substring(0, indexOfIntID) + String(xbeeTimer) + IDterminator + "DATA" + stringTerminator + String(inboxTerminator));       // Send XBee data every XBee send value times, allows for multiple devices to send on different values of xbeeTimer
      if (xbeeTimer >= xbeeRate) xbeeTimer = xbeeTimerStart;  // Reset  xbeeTimer when xbeeRate is reached
      if (xbeeRate != 0) xbeeTimer++;
      xbeeTimerSec = millis();
      //while(XBeeSerial.available() == 0 && millis() - xbeeTimerSec < (xbeeDelay/2)) listenXBee();
  }

}

////////////////////////////////////////////// Functions ///////////////////////////////////////////////
// void wait(unsigned const int); 
// void updateButtonStatus();
// void updateSwitchStatus();
// bool sdSetup(char *dataFile, byte const &N1, byte const &N2);
// void logData(String const &Data, char const *dataFile);
// void updateIMU();
// void printEvent(sensors_event_t*);
// void updateBNO();
// String flightTimeStr(unsigned long);
// float updateFrequency(unsigned long _time);
// void heaterSetup();
// float updateHeater();
// void dataUpdate();

void wait(unsigned const int t){ //Soft pause placed in code
  while(millis() - timer <= t) {}
  timer = millis();
}

bool updateButtonStatus(){ 
  bool buttonStatus = false;
  buttonStatus = (digitalRead(BUTTON_PIN) == 0) ? true : false;
  return buttonStatus;
}

bool updateSwitchStatus(){
  bool switchStatus = false;
  switchStatus = (digitalRead(SWITCH_PIN) == 0) ? true : false;
  return switchStatus;
}

bool sdSetup(char *dataFile, byte const &N1, byte const &N2){
  pinMode(CHIP_SELECT,OUTPUT);
  if(!SD.begin(CHIP_SELECT)) sdStatus = 0;
  //if(!Sd.begin(CHIP_SELECT, SPI_FULL_SPEED)) sdStatus = 0;
  else {
      sdStatus = 1;
      for (byte i = 0; i < 100; i++) {
          dataFile[N1] = '0' + i/10; 
          dataFile[N2] = '0' + i%10;
          if (!SD.exists(dataFile)) {
          //if (!Sd.exists(dataFile)) {
              datalog = SD.open(dataFile, FILE_WRITE);
              //datalog.open(dataFile, O_CREAT | O_APPEND | O_WRITE);
              //datalog.open(dataFile, FILE_WRITE);
              sdActive = true;
              datalog.close();
              break;
          }
          else sdActive = false;
      }
  } 
  return sdStatus;
}

void logData(String const &Data, char const *dataFile){
  //if (*dataFile == "Configuration.txt") datalog = SD.open(dataFile, FILE_WRITE);
  //datalog.open(dataFile, O_APPEND | O_WRITE);
  datalog = SD.open(dataFile, FILE_WRITE);
  //datalog.open(dataFile, FILE_WRITE);
  datalog.seek(EOF);
  datalog.println(Data);
  datalog.close();
}

void updateIMU(){ // Update the Mag, Acc, and Gyro on the LSM9DS1
  if(lsm.gyroAvailable()) lsm.readGyro();
  if(lsm.accelAvailable()) lsm.readAccel();
  if(lsm.magAvailable()) lsm.readMag();

  magnetometer[0] = lsm.calcMag(lsm.mx);
  magnetometer[1] = lsm.calcMag(lsm.my);
  magnetometer[2] = lsm.calcMag(lsm.mz);
  accelerometer[0] = lsm.calcAccel(lsm.ax);
  accelerometer[1] = lsm.calcAccel(lsm.ay);
  accelerometer[2] = lsm.calcAccel(lsm.az);
  gyroscope[0] = lsm.calcGyro(lsm.gx);
  gyroscope[1] = lsm.calcGyro(lsm.gy);
  gyroscope[2] = lsm.calcGyro(lsm.gz);

  float roll = atan2(accelerometer[1], accelerometer[2]);
  float pitch = atan2(-accelerometer[0], sqrt(accelerometer[1] * accelerometer[1] + accelerometer[2] * accelerometer[2]));
  float heading;

  if (magnetometer[1] == 0) heading = (magnetometer[0] < 0) ? PI : 0;
  else heading = atan2(magnetometer[0], magnetometer[1]);

  heading -= DECLINATION * PI / 180;

  if (heading > PI) heading -= (2 * PI);
  else if (heading < -PI) heading += (2 * PI);

  // Convert everything from radians to degrees:
  heading *= 180.0 / PI;
  pitch *= 180.0 / PI;
  roll  *= 180.0 / PI;

  orientation[0] = heading;
  orientation[1] = pitch;
  orientation[2] = roll;
}

void printEvent(sensors_event_t* event) {
  if (event->type == SENSOR_TYPE_ACCELEROMETER) {
      accelerometer[0] = (float)event->acceleration.x;
      accelerometer[1] = (float)event->acceleration.y;
      accelerometer[2] = (float)event->acceleration.z;
  }
  else if (event->type == SENSOR_TYPE_ORIENTATION) {
      orientation[0] = (float)event->orientation.x;
      orientation[1] = (float)event->orientation.y;
      orientation[2] = (float)event->orientation.z;
  }
  else if (event->type == SENSOR_TYPE_MAGNETIC_FIELD) {
      magnetometer[0] = (float)event->magnetic.x;
      magnetometer[1] = (float)event->magnetic.y;
      magnetometer[2] = (float)event->magnetic.z;
  }
  else if (event->type == SENSOR_TYPE_GYROSCOPE) {
      gyroscope[0] = (float)event->gyro.x;
      gyroscope[1] = (float)event->gyro.y;
      gyroscope[2] = (float)event->gyro.z;
  }
}

void updateBNO(){
  //could add VECTOR_ACCELEROMETER, VECTOR_MAGNETOMETER, VECTOR_GRAVITY...
  sensors_event_t orientationData, angVelocityData, magnetometerData, accelerometerData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  bno.getEvent(&angVelocityData, Adafruit_BNO055::VECTOR_GYROSCOPE);
  bno.getEvent(&magnetometerData, Adafruit_BNO055::VECTOR_MAGNETOMETER);
  bno.getEvent(&accelerometerData, Adafruit_BNO055::VECTOR_ACCELEROMETER);

  accelerometer[0] = (float)accelerometerData.acceleration.x;
  accelerometer[1] = (float)accelerometerData.acceleration.y;
  accelerometer[2] = (float)accelerometerData.acceleration.z;
  orientation[0] = (float)orientationData.orientation.x;
  orientation[1] = (float)orientationData.orientation.y;
  orientation[2] = (float)orientationData.orientation.z;
  magnetometer[0] = (float)magnetometerData.magnetic.x;
  magnetometer[1] = (float)magnetometerData.magnetic.y;
  magnetometer[2] = (float)magnetometerData.magnetic.z;
  gyroscope[0] = (float)angVelocityData.gyro.x;
  gyroscope[1] = (float)angVelocityData.gyro.y;
  gyroscope[2] = (float)angVelocityData.gyro.z;

  uint8_t system, gyro, accel, mag = 0;
  bno.getCalibration(&system, &gyro, &accel, &mag);
}

String flightTimeStr(unsigned long t) { // Turns a time in seconds to a usable string for print statements  
  String fTime = "";                    // Format: "00:00:00" -> h:m:s
  fTime += (String(t / 3600) + ":");
  t %= 3600;
  fTime += String(t / 600);
  t %= 600;
  fTime += (String(t / 60) + ":");
  t %= 60;
  fTime += (String(t / 10) + String(t % 10));
  return fTime;
}

float updateFrequency(unsigned long _time){
  float frequency = 1.0 / ((_time - pastTime)/1000.0);
  pastTime = _time;
  return frequency;
}

void heaterSetup(){
  pinMode(heaterSet,OUTPUT);
  pinMode(heaterReset,OUTPUT);

  while (ThermistorHeater.getStatus() == 0){
      if(millis()-timer > 250){
          _print = (ThermistorHeater.begin(12)) ? "Therm Htr Online!" : "Therm Htr Offline...Skip: B\nRetry: S";
          Serial.println(_print);  // Since this is a Teensy we are using, the read bit resolution can be at a max of 13 (12 for Teensy 4.1).
          OLED.update(_print);     // The maximum adc value given to the thermistor, should be 8191 (2^13) for a Teensy 3.6, 
          timer = millis();        // 4095 (2^12) for a Teensy 4.1, and 1023 (2^10) for an Arduino
      }
      if(ThermistorHeater.getStatus() == 0) while(updateButtonStatus() == 0 && updateSwitchStatus() == 0) delay(20);
      if (updateButtonStatus()) break; 
  }
}

float updateHeater() {
  if (ThermistorHeater.getStatus()){
      ThermistorHeater.update();
      if(ThermistorHeater.getTempF() <= minimumTemperature && heaterStatus != "ON"){ 
          digitalWrite(heaterReset,HIGH);
          delay(10);
          digitalWrite(heaterReset,LOW);
          heaterStatus = "ON";
      }
      else if(ThermistorHeater.getTempF() >= maximumTemperature && heaterStatus != "OFF"){ 
          digitalWrite(heaterSet,HIGH);
          delay(10); 
          digitalWrite(heaterSet,LOW);
          heaterStatus = "OFF";
      }
  }
  return ThermistorHeater.getTempF();
}


void dataUpdate(){
  LED2.on();
  timerSec = (timer * 1.0) / 1000.0;

  timer2 = millis();
  if (gpsStatus == 7) gpsUpdate();
  timer2 = millis() - timer2;

  timer3 = millis();
  fullTimer = flightTimeStr(timerSec);
  frequencyHz = updateFrequency(timer);

  if (usingHeater) updateHeater();
  ThermistorInt.update();
  ThermistorExt.update();

  #ifdef R1_ACTUAL
  inputVoltage = analogRead(VOLTAGE_READER_PIN);
  inputVoltage = inputVoltage/4096.0 * 3.3 * ((R1_THEORETICAL+R2_THEORETICAL)/ R2_ACTUAL);
  #else
  inputVoltage = analogRead(VOLTAGE_READER_PIN);
  inputVoltage = inputVoltage/4096.0 * 3.3 * ((R1_THEORETICAL+R2_THEORETICAL) / R2_THEORETICAL);
  #endif

  timer3 = millis() - timer3;

  timer4 = millis();
  if (lsmStatus) updateIMU();
  if (bnoStatus) updateBNO();
  timer4 = millis() - timer4;
  
  timer5 = millis();
  if (msStatus){
      MS5611.update();
      if (MS5611.msAltitudeFt - altFtStart > 100 && !flightTimerStatus) {
          flightStartTime = timerSec;
          flightTimerStatus = true;
          oledOn = false;
          OLED.update("\n\n  Flight\n Started!");
      }
      if (flightTimerStatus) flightTimerString = flightTimeStr(int(timerSec) - flightStartTime);
  }
  timer5 = millis() - timer5;
  

  timer6 = millis();

  // Data String Assembly
  data = fullTimer + "," + flightTimerString + "," + String(timerSec, 2) + "," + String(timer) + "," + String(frequencyHz, 1) + "," + String(timer2) + "," + String(timer5) + "," + String(timer7) + "," + String(timer8) + "," + String(inputVoltage) + "," +
  
  fixTypeGPS + "," + fixTypeRTK + "," + String(pvtStatus) + "," + String(SIV) + "," + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear) + "," +
  String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond) + ".";
  if (gpsMillisecond < 10) data += "00" + String(gpsMillisecond) + ",";
  else if (gpsMillisecond < 100) data += "0" + String(gpsMillisecond) + ",";
  else data += String(gpsMillisecond) + ",";
  
  //data += String(gpsLat) + "," + String(gpsLon) + "," + String(gpsAltFt) + "," + String(gpsAltM) + "," + String(gpsVertVelFt) + "," + String(gpsVertVelM) + ",";

  char paddedNumber[8]; // Buffer to hold the padded number (7 digits + null terminator)
  data += String(gpsLatInt) + ".";
  // Format the number with padded zeros using sprintf()
  sprintf(paddedNumber, "%07ld", gpsLatDec);
  data += String(paddedNumber); // Pad the number with zeros up to 7 digits
  data += ",";

  data += String(gpsLonInt) + ".";
  // Format the number with padded zeros using sprintf()
  sprintf(paddedNumber, "%07ld", gpsLonDec);
  data += String(paddedNumber); // Pad the number with zeros up to 7 digits
  data += ",";

  data += String(gpsAltFt) + "," + String(gpsAltM) + ",";
  data += String(gpsHorizAcc) + "," + String(gpsVertAcc) + ",";
  data += String(gpsVertVelFt) + "," + String(gpsVertVelM) + ",";

  // if(gpsFast){
      data += String(ecefStatus) + "," + String(ecefX) + "," + String(ecefY) + "," + String(ecefZ) + "," + 
      String(UTMZoneNum) + String(UTMZoneLetter) + "," + String(UTMEasting, 0) + "," + String(UTMNorthing, 0) + ",";
  // }

  data += String(velocityNED[0], 3) + "," + String(velocityNED[1], 3) + "," + String(velocityNED[2], 3) + ",";

  data += String(gpsGndSpeed, 3) + "," + String(gpsHeading) + "," + String(gpsPDOP, 0) + ",";

  if(usingHeater){
      data += String(ThermistorHeater.getTempF()) + "," + heaterStatus + ",";
  }

  data += String(ThermistorInt.getTempC()) + "," + String(ThermistorInt.getTempF()) + "," + String(ThermistorExt.getTempC()) + "," + String(ThermistorExt.getTempF()) + "," + 
  
  String(MS5611.msTemperatureC) + "," + String(MS5611.msTemperatureF) + "," + String(MS5611.msPressureMBar) + "," + String(MS5611.msPressurePSI) + "," + String(MS5611.msPressureATM) + "," + 
  String(MS5611.msAltitudeFt) + "," + String(MS5611.msAltitudeM) + "," + String(MS5611.msVertVelFt) + "," + String(MS5611.msVertVelM) + "," +

  String(magnetometer[0]) + "," + String(magnetometer[1]) + "," + String(magnetometer[2]) + "," +
  String(accelerometer[0]) + "," + String(accelerometer[1]) + "," + String(accelerometer[2]) + "," +
  String(gyroscope[0]) + "," + String(gyroscope[1]) + "," + String(gyroscope[2]) + "," +
  String(orientation[0]) + "," + String(orientation[2]) + "," + String(orientation[1]);

  data = data  + "," +  String(xbeeMessage); 
  xbeeMessage = "";                             // Data String Assembly end

  //Serial.println(dataDelay);
  //Serial.println("(h:m:s),FlightT,sec,Sat,Date,GPSTime,GPSLat   ,GPSLon.   ,Alt(Ft),Alt M,ECEF X ,ECEF Y  ,ECEF Z ,Zo#,Easting,Northing,GndSpd(m/s),Head(deg),PDOP,intT(C),intT(F),extT(C),extT(F),msTemp(C),msTemp(F),msPress(PSI),msPress(ATM),msAlt(ft),msAlt(M),VertVel(Ft/S),VertVel(M/S),mag x,mag y,mag z,accel x,accel y,accel z,gyro x,gyro y,gyro z,orien yaw,orien pitch,orien roll,xbee message");
  Serial.println(data); // Serial Print data

  timer6 = millis() - timer6;

  timer7 = millis();

  if(oledOn){
      if(oledCounter == 0){ // OLED Assembly Start
          strOLED = String(gpsLat,4) + "\n" + String(gpsLon,4) + "\n" + String(gpsAltFt, 2) + "ft\n";
          strOLED += String(SIV);
          strOLED2 = String(SIV);
          for(int i=strOLED2.length(); i<3; i++){
              strOLED += " ";
          }
          strOLED += "S " + String(frequencyHz, 1) + "\nI:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(inputVoltage, 2) + " V";
          OLED.update(strOLED);
      }

      else if(oledCounter == 1){
          strOLED = String(ecefX/100);
          for(int i=strOLED.length(); i<9; i++){
              strOLED += " ";
          }
          strOLED += "X";
          strOLED2 = strOLED;
          strOLED = String(ecefY/100);
          for(int i=strOLED.length(); i<9; i++){
              strOLED += " ";
          }
          strOLED += "Y";
          strOLED2 += strOLED;
          strOLED = String(ecefZ/100);
          for(int i=strOLED.length(); i<9; i++){
              strOLED += " ";
          }
          strOLED += "Z";
          strOLED2 += strOLED;
          strOLED = String(SIV);
          for(int i=strOLED.length(); i<3; i++){
              strOLED += " ";
          }
          strOLED += "S " + String(frequencyHz, 1);
          strOLED2 += strOLED + "\nI:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI";
          OLED.update(strOLED2);                         // OLED Assembly End
      }

      else if(oledCounter == 2){
          strOLED = String(UTMZoneNum) + String(UTMZoneLetter) + "\n" + String(UTMEasting,0) + "\n" + String(UTMNorthing, 0) + "\n";
          strOLED += String(SIV);
          strOLED2 = String(SIV);
          for(int i=strOLED2.length(); i<3; i++){
              strOLED += " ";
          }
          strOLED += "S " + String(frequencyHz, 1) + "\nI:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI";
          OLED.update(strOLED);
      }
      
      else if(oledCounter == 3){
          strOLED = "Y " + String(orientation[0]) + "\nP " + String(orientation[2]) + "\nR " + String(orientation[1]) + "\n";
          strOLED += String(SIV);
          strOLED2 = String(SIV);
          for(int i=strOLED2.length(); i<3; i++){
              strOLED += " ";
          }
          strOLED += "S " + String(frequencyHz, 1) + "\nI:" + String(int(ThermistorInt.getTempF())) + " E:" + String(int(ThermistorExt.getTempF())) + "\n" + String(MS5611.msPressurePSI,2) + " PSI";
          OLED.update(strOLED);
      }
      
      else if(oledCounter == 4){
          OLED.update(String(dataFilename) + String(xbeeFilename) + "\nC" + channelID + " N:" + networkID + "ID:" + String(xbeeID) + " XT:" + String(xbeeTimer) + "HTR:" + String(ThermistorHeater.getTempF(),1) + "\nStat:" + heaterStatus);
      }

      else if(oledCounter == 5){
          strOLED = fullTimer + "\n" + flightTimerString + "\n" + String(gpsHour) + ":" + String(gpsMinute) + ":" + String(gpsSecond) + "\n" + String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear);
          strOLED2 = String(gpsMonth) + "/" + String(gpsDay) + "/" + String(gpsYear);
          for(int i=strOLED2.length(); i<10; i++){
              strOLED += " ";
          }
          strOLED += String(MS5611.msAltitudeFt, 1) + " ft\n";
          strOLED += String(MS5611.msTemperatureF) + " F";
          OLED.update(strOLED);
      }

      //OLED.update(String(ecefX, 0) + " X\n" + String(ecefY, 0) + "Y\n" + String(ecefZ, 0) + " Z\n" + String(SIV) + " Sats\nInt:" + String(int(ThermistorInt.getTempF())) + " F\n" + String(MS5611.msPressurePSI,2) + " PSI");
  }
  timer7 = millis() - timer7;

  timer8 = millis();
  //logData(data, dataFilename);  // Log data to SD
  //datalog = SD.open(dataFilename, FILE_WRITE);
  // datalog.seek(EOF);
  // datalog.println(data);
  // datalog.flush();

  dataAdded += data;
  if (dataCounter == 9){
      logData(dataAdded, dataFilename);  // Log data to SD
      dataAdded = "";
  }
  dataCounter++;
  if (dataAdded != "") dataAdded += "\n";
  if (dataCounter == 10) dataCounter = 0;

  // logData(data, dataFilename);  // Log data to SD
  // dataAdded = "";

  timer8 = millis() - timer8;
  data = "";

  timerTotal = timer2 + timer3 + timer4 + timer5 + timer6 + timer7 + timer8;
  
  Serial.print( String(timer2) + "," + String(timer3) + "," + String(timer4) + "," + String(timer5) + "," + String(timer6) + "," + String(timer7) + "," + String(timer8) + "," + String(timerTotal) + " (ms)   ");

  LED2.off(); 
}
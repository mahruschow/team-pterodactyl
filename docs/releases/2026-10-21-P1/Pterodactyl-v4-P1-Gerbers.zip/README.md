# Pterodactyl v4 P1 — updated with team names

Current PCB SHA-256: 81e55601eedce1db9af4605c51e35552ac0a704867d0fd5996423eb1861b1d09

The bottom silkscreen includes Saadat Muyeen, Mahrus Chowdhury and Ryeed Zaman. Only three text objects changed. DRC, connectivity, parity and fabrication checks pass. Other copper/mask/front-legend/outline Gerber geometry is unchanged.

AISLER TCVOYNZG revision 1 is an older upload WITHOUT the names. Sign in and upload this updated native board or the current Gerber ZIP, then inspect the bottom preview before ordering. Anonymous revision upload failed; no new revision and no order were created.

Order specification: 3 bare PCBs, four layers, 1.6 mm, 35 um copper, ENIG, green mask, white legend, no stencil/add-ons. The default .gbrjob is intentionally excluded; the selected AISLER service controls the stackup. The previous EUR quote is historical until checkout is refreshed.

Read docs/FIRST_PROTOTYPE_RELEASE.md for assembly and operating limitations. This is a first-prototype release, not cold/runtime/flight qualification. The optional bench holder fits the same unchanged board outline and mounting holes.

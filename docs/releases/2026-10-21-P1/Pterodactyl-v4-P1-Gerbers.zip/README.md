# Pterodactyl v4 P1 - first prototype

Start with docs/FIRST_PROTOTYPE_RELEASE.md. AISLER project TCVOYNZG revision 1 processed successfully and is ready for account checkout. Nothing has been ordered. User scope is the first assembled prototype; physical testing, flight qualification, later revisions and casing are outside this phase.

The Native_KiCad_v4 board is the exact uploaded file. Do not use old component-review ZIPs for this order. Native source is a snapshot of the uncommitted saadat-dev working tree, not a Git commit. Local libraries are included, standard KiCad 10 libraries are required. Continue editing the original repository.

Board order: 3 bare PCBs, 4 layers, 1.6 mm, 35 um copper, ENIG, green mask, white legend, no stencil/add-ons. Current anonymous quote EUR 51.37 net; actual tax/shipping and payment require sign-in. Only one populated prototype's component quantities are listed. Test pads and DNP J4 excluded from purchase list.

Manufacturing alternative: use the separate Pterodactyl-v4-P1-Gerbers.zip. Stackup follows AISLER's selected service; default .gbrjob dielectric entries are intentionally excluded. Assembly drawing is for placement, not manufacturing input. Read polarity, USB isolation and harness instructions before assembly.
